from tkinter import *
from tkinter import messagebox
from tkinter import ttk

import pymysql
from PIL import Image, ImageTk


# from pymysql import *


def main():
    win = Tk()
    app = Login_Window(win)
    win.mainloop()

    # ~~~~~~~~~~~~~~~~~~.................A Login Window Class...................~~~~~~~~~~~~~~~~#


class Login_Window:
    def __init__(self, root):
        self.root = root
        self.root.title("Login")
        self.root.geometry("1550x800+0+0")

        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~..............Whole Login window Background Image.................~~~~~~~~~~~~~#
        self.bg = ImageTk.PhotoImage(file=r"bokeh-colorful-lights-blurred-lm.jpg")

        lbl_bg = Label(self.root, image=self.bg)
        lbl_bg.place(x=0, y=0, relwidth=1, relheight=1)
        # ~~~~~~~~~~.....................Frame-1 Adminstrator Frame..............~~~~~~~~~~~~~~~~~~~~~~~~~~~#
        Fframe1 = Frame(self.root, bg="white")
        Fframe1.place(x=750, y=390, width=1240, height=280)
        # ~~~~~~~~......................Frame-2 Face Detection Stuff..............~~~~~~~~~~~~~~~~~~~~~~#
        Fframe2 = Frame(self.root, bg="white")
        Fframe2.place(x=0, y=90, width=630, height=280)
        # ~~~~~~~~~~~~~~~~~~~~~.........Icon for administrator Login..............~~~~~~~~~~~~~~~#

        img1 = Image.open(r"C:\Users\PRINCE\Desktop\project\OIP.jfif")
        img1 = img1.resize((100, 100), Image.ANTIALIAS)
        self.photoimage1 = ImageTk.PhotoImage(img1)
        lblimg1 = Label(image=self.photoimage1, bg="green", borderwidth=0)
        lblimg1.place(x=800, y=400, width=100, height=100)
        # Logo for student
        img2 = Image.open(r"C:\Users\PRINCE\Desktop\project\download.jfif")
        img2 = img2.resize((100, 100), Image.ANTIALIAS)
        self.photoimage2 = ImageTk.PhotoImage(img2)
        lblimg2 = Label(image=self.photoimage2, bg="red", borderwidth=0)
        lblimg2.place(x=10, y=100, width=100, height=100)
        # ~~~~~~~~~~~~~~~~~~~~~Lables For Guidence....................~~~~~~~~~~~~~~~#
        get_str = Label(Fframe1, text="Note:For Adminstrator Only", font=("times new roman", 20, "bold"), fg="black",
                        bg="white")
        get_str.place(x=190, y=38)
        get_str1 = Label(Fframe2, text="Initiate Attendence Taking System", font=("times new roman", 20, "bold"),
                         fg="black", bg="white")
        get_str1.place(x=150, y=50)
        # ~~~~~~~~~~~UserName Label~~~~~~~~~~~~~~~~#
        username = lbl = Label(Fframe1, text="Username", font=("times new roman", 15, "bold"), fg="black", bg="white")
        username.place(x=60, y=120)
        self.txtuser = ttk.Entry(Fframe1, font=("constantia", 13))
        self.txtuser.place(x=200, y=120, width=300)
        # ~~~~~~~~~~~~~~~~~~Password Taking ~~~~~~~~~~~~~~~~~~~~#
        password = lbl = Label(Fframe1, text="Password", font=("times new roman", 15, "bold"), fg="black", bg="white")
        password.place(x=60, y=160)

        self.txtpass = ttk.Entry(Fframe1, show="*", font=("constantia", 13))
        self.txtpass.place(x=200, y=160, width=300)
        # ~~~~~~~~~~~~~~~Login Button~~~~~~~~~~~~~~~~~~~~#
        loginbtn = Button(Fframe1, command=self.login, text="Login", font=("times new roman", 15, "bold"), bd=3,
                          relief=RIDGE, fg="black", cursor="hand2", bg="lightgreen", activeforeground="black",
                          activebackground="lightgreen")
        loginbtn.place(x=290, y=200, width=120, height=40)
        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~Register Button~~~~~~~~~~#
        registerbtn = Button(Fframe1, text="New User Register", command=self.register_window_open,
                             font=("times new roman", 15, "bold"), borderwidth=0, fg="black", bg="white",
                             cursor="hand2", activebackground="white")
        registerbtn.place(x=30, y=240, width=200)
        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Forgot Password Button~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
        forgetbtn = Button(Fframe1, command=self.Forgot_Pass, text="Forget Password",
                           font=("times new roman", 15, "bold"), borderwidth=0,
                           fg="black", bg="white", cursor="hand2", activebackground="white")
        forgetbtn.place(x=450, y=240, width=150)
        ####################################### Open register At toplever#####################################################

    def register_window_open(self):
        self.new_window = Toplevel(self.root)
        self.app = Register(self.new_window)

        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~Login Stuff~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#

    def login(self):
        if self.txtuser.get() == "" or self.txtpass.get() == "":
            messagebox.showerror("OOPS!!", "Username and Password Must be required")
        else:
            try:
                con = pymysql.connect(host='localhost', user='root', password='0000', database='project')
                cur = con.cursor()
                cur.execute('select * from teacher where TID=%s and PASS=%s', (self.txtuser.get(), self.txtpass.get()))
                row = cur.fetchone()
                if row == None:
                    messagebox.showerror("Error", "Invalid UserNmae or Password", parent=self.root)
                    self.txtuser.delete(0, END)
                    self.txtpass.delete(0, END)
                    self.txtuser.focus()
                else:
                    self.homepage()
                    con.close()
            except Exception as es:
                messagebox.showerror('Error', f'Error Due to : {str(es)}', parent=self.root)

    def Forgot_Pass(self):
        try:
            if self.txtuser.get() == "":
                messagebox.showerror('Error', 'User Must Enter its Username')
            else:
                con = pymysql.connect(host='localhost', user='root', password='0000', database='project')
                cur = con.cursor()
                cur.execute('select TID from teacher where TID=%s', self.txtuser.get())
                row = cur.fetchone()
                if row == None:
                    messagebox.showerror("Error", "Enterd UserName Not Contained in our Database", parent=self.root)
                else:
                    self.root2 = Toplevel()
                    self.root2.title("Forgot Password")
                    self.root2.geometry("440x800+0+0")
                    l = Label(self.root2, text="Forgot Password", font=("monospace", 15, "bold"))
                    l.place(x=10, y=30, relwidth=1)
                    SelQue = Label(self.root2, text="Select Question", font=("times new roman", 14, "bold"),
                                   bg="white")
                    SelQue.place(x=50, y=100)
                    self.Rcombo_que = ttk.Combobox(self.root2, font=("times new roman", 14, "bold"), state="readonly")
                    self.Rcombo_que["values"] = ("Select", "your Birth Place?", "Your Pet Name?", "Your Birth Year?")
                    self.Rcombo_que.place(x=50, y=130, width=225)
                    self.Rcombo_que.current(0)
                    SelAns = Label(self.root2, text="Answer", font=("times new roman", 17, "bold"), bg="white",
                                   fg="black")
                    SelAns.place(x=50, y=190)
                    self.RSelAns = ttk.Entry(self.root2, font=("monospace", 15, "italic"))
                    self.RSelAns.place(x=50, y=220)
                    self.Butt = Button(self.root2, command=self.forgot_thing, text="Check",
                                       font=("monospace", 14, "bold"), foreground="green",
                                       background="yellow")
                    self.Butt.place(x=130, y=300, width=100)
                    con.commit()
                    con.close();
        except EXCEPTION as es:
            messagebox.showerror("Error", f"Error due to {str(es)}", parent=self.root2)

    def forgot_thing(self):
        try:
            var1 = StringVar()

            con = pymysql.connect(host='localhost', user='root', password='0000', database='project')
            cur = con.cursor()
            cur.execute('select SEQQ from teacher where SEQQ=%s', self.Rcombo_que.get())
            row = cur.fetchone()
            cur.execute('select SEQA from teacher where TID=%s', self.txtuser.get())
            row1 = cur.fetchone()
            if self.Rcombo_que.get() == "Select" or self.RSelAns.get() == "":
                messagebox.showerror("Error", "All fields are Mandatory!!", parent=self.root2)
            elif row == None:
                messagebox.showerror("Error", "Are u Certain U selected This Security Question", parent=self.root2)
            elif self.RSelAns.get() != row1[0]:
                messagebox.showerror("Error", "Wrong Sequrity Answer", parent=self.root2)
            else:
                self.txtpass.insert(0, row1[0])
                messagebox.showinfo("Success", "Now You can Login!", parent=self.root2)
                con.commit()
                con.close()
                self.root2.destroy()
        except EXCEPTION as es:
            messagebox.showerror("Error", f"Error due to {str(es)}", parent=self.root2)


class Register:
    def __init__(self, root):
        self.root = root
        self.root.title("Register")
        self.root.geometry("1400x750+0+0")
        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~Variables~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        self.var_SeqQ = StringVar()
        self.var_Gen = StringVar()
        self.var_Dept = StringVar()

        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~FULL BACKGROUND IMAGE ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
        self.bg = ImageTk.PhotoImage(file=r"feather-focus-blur-sunset-5k-yv.jpg")
        bg_lbl = Label(self.root, image=self.bg)
        bg_lbl.place(x=0, y=0, relwidth=1, relheight=1, height=2, width=50)
        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~LEFT IMAGE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~`#

        self.bg1 = ImageTk.PhotoImage(file=r"bokeh-colorful-lights-blurred-lm.jpg")
        bg_lbl1 = Label(self.root, image=self.bg1)
        bg_lbl1.place(x=100, y=70, width=370, height=550)
        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~Register Frame~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
        Rframe = Frame(self.root, bg="white")
        Rframe.place(x=470, y=70, width=770, height=550)
        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~REGESTRATION LABEL~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
        Register_lbl = Label(Rframe, text="Registration Form", font=("times new roman", 25, "bold"), fg="orangered",
                             bg="white")
        Register_lbl.place(x=50, y=20)
        TiD = Label(Rframe, text="Teacher's ID", font=("times new roman", 17, "bold",), bg="white", fg="black")
        TiD.place(x=50, y=70)
        self.RegTID = ttk.Entry(Rframe, font=("monospace", 15, "italic"))
        self.RegTID.place(x=50, y=100)
        # !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!First_Name!!!!!!!!!!!!!!!!!!!!!!!!#
        F_Name = Label(Rframe, text="First Name", font=("times new roman", 17, "bold",), bg="white", fg="black")
        F_Name.place(x=50, y=150)
        self.RegF_Name = ttk.Entry(Rframe, font=("monospace", 15, "italic"))
        self.RegF_Name.place(x=50, y=180)
        ###################################################LAST NAME####################################################
        L_Name = Label(Rframe, text="Last Name", font=("times new roman", 17, "bold",), bg="white")
        L_Name.place(x=350, y=150)
        self.RegL_Name = ttk.Entry(Rframe, font=("monospace", 15, "italic"))
        self.RegL_Name.place(x=350, y=180)
        ############################################### Email Id###########################################################
        E_Mail = Label(Rframe, text="E-Mail", font=("times new roman", 17, "bold",), bg="white")
        E_Mail.place(x=350, y=70)
        self.RegEmail = ttk.Entry(Rframe, font=("monospace", 15, "italic"))
        self.RegEmail.place(x=350, y=100)
        #######################################PASSWORD #########################################
        Pass = Label(Rframe, text="Password", font=("times new roman", 17, "bold",), bg="white", fg="black")
        Pass.place(x=50, y=230)
        self.RegPass = ttk.Entry(Rframe, font=("monospace", 15, "italic"))
        self.RegPass.place(x=50, y=260)
        #########################################Confirm Password####################################
        ConfPass = Label(Rframe, text="Confirm Password", font=("times new roman", 17, "bold",), bg="white", fg="black")
        ConfPass.place(x=350, y=230)
        self.RegConPass = ttk.Entry(Rframe, font=("monospace", 15, "italic"))
        self.RegConPass.place(x=350, y=260)
        ##########################################SELECT SEQURITY QUESTION ##############################################
        SelQue = Label(Rframe, text="Select Question", font=("times new roman", 17, "bold"), bg="white")
        SelQue.place(x=50, y=310)
        ########################################SECURITY ANSWER##################################
        SelAns = Label(Rframe, text="Answer", font=("times new roman", 17, "bold"), bg="white", fg="black")
        SelAns.place(x=350, y=310)
        self.RegSelAns = ttk.Entry(Rframe, font=("monospace", 15, "italic"))
        self.RegSelAns.place(x=350, y=340)
        Dept = Label(Rframe, text="Department", font=("times new roman", 17, "bold"), bg="white")
        Dept.place(x=50, y=390)
        self.RegComDept = ttk.Combobox(Rframe, textvariable=self.var_Dept, font=("times new roman", 15, "bold"),
                                       state="readonly")
        self.RegComDept.place(x=50, y=420, width=225)
        self.RegComDept["values"] = ("Select", "Bsc.Ca", "Bsc It")
        self.RegComDept.current(0)
        self.Regcombo_que = ttk.Combobox(Rframe, textvariable=self.var_SeqQ, font=("times new roman", 15, "bold"),
                                         state="readonly")
        self.Regcombo_que["values"] = ("Select", "your Birth Place?", "Your Pet Name?", "Your Birth Year?")
        self.Regcombo_que.place(x=50, y=340, width=225)
        self.Regcombo_que.current(0)

        ######################################################GENTER #########################
        RegGen = Label(Rframe, text="Gender", font=("times new roman", 17, "bold"), bg="white", fg="black")
        RegGen.place(x=350, y=390)
        self.ComboGen = ttk.Combobox(Rframe, textvariable=self.var_Gen, font=("times new roman", 15, "bold"),
                                     state="readonly")
        self.ComboGen["values"] = ("Select", "Male", "Female", "Other")
        self.ComboGen.place(x=350, y=420, width=225)
        self.ComboGen.current(0)

        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~Button~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
        self.Regbtm = Button(Rframe, text="Register", command=self.register_button,
                             font=("times new roman", 17, "bold"), borderwidth=0, cursor="hand2", bg="orangered",
                             activebackground="orangered")
        self.Regbtm.place(x=380, y=480, width=200, height="50")
        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~Back Button!~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
        BackBtn = Button(Rframe, text="Already Registred?Log in", command=self.des,
                         font=("times new roman", 17, "bold"), borderwidth=0, cursor="hand2", bg="white",
                         activebackground="white")
        BackBtn.place(x=20, y=480, width=300, height="50")

    def des(self):
        self.win = Toplevel(self.root)
        Login_Window(self.win)

    def register_button(self):
        if self.RegTID.get() == "" or self.RegEmail.get() == "" or self.RegF_Name.get() == "" or self.RegL_Name.get() == "" or self.RegPass.get() == "" or self.RegConPass.get() == "" or self.var_SeqQ.get() == "Select" or self.var_Dept.get() == "Select" or self.RegSelAns.get() == "" or self.var_Gen.get() == "Select":
            messagebox.showerror("Error", "Fields Cannot Be Empty", parent=self.root)
        elif self.RegPass.get() != self.RegConPass.get():
            messagebox.showerror("Error", "Diffrent Password entered", parent=self.root)
        else:
            try:
                con = pymysql.connect(host="localhost", user="root", password="0000", database="project")
                cur = con.cursor()
                cur.execute("select * from teacher where E_MAIL=%s", self.RegEmail.get())
                row = cur.fetchone()
                cur1 = con.cursor()
                cur1.execute("select * from teacher where TID=%s", self.RegTID.get())
                row1 = cur1.fetchone()
                if row != None:
                    messagebox.showerror("Error", "Email Address is Already Registred!!", parent=self.root)
                    self.RegEmail.delete(0, END)
                    self.RegEmail.focus()
                elif row1 != None:
                    messagebox.showerror("Error", "Enter UserName is Already Registered!!", parent=self.root)
                    self.RegTID.delete(0, END)
                    self.RegTID.focus()
                else:
                    cur2 = con.cursor()
                    cur2 = con.cursor()
                    cur2.execute(
                        " insert into teacher (TID,F_NAME,L_NAME,E_MAIL,PASS,GEN,SEQQ,SEQA,DEPT)values(%s,%s,%s,%s,%s,%s,%s,%s,%s)",
                        (self.RegTID.get(), self.RegF_Name.get(), self.RegL_Name.get(), self.RegEmail.get(),
                         self.RegPass.get(), self.var_Gen.get(), self.var_SeqQ.get(), self.RegSelAns.get(),
                         self.var_Dept.get()))
                    con.commit()
                    con.close()
                    messagebox.showinfo("Registred", "redirecting to home!!", parent=self.root)
            except Exception as es:
                messagebox.showerror("Error", f"Erorr due to{str(es)} :", parent=self.root)


if __name__ == "__main__":
    main()
