from tkinter import *
from tkinter import messagebox, ttk
from datetime import date
import pymysql
from PIL import ImageTk, Image
global x_username
class Student_Login_Page:
    def __init__(self, window):
        self.window = window
        self.window.geometry('1166x718')
        self.window.resizable(0, 0)
        self.window.state('zoomed')
        self.window.title('Login Page')

        # ========================================================================
        # ============================background image============================
        # ========================================================================
        self.bg_frame = Image.open('background1.png')
        photo = ImageTk.PhotoImage(self.bg_frame)
        self.bg_panel = Label(self.window, image=photo)
        self.bg_panel.image = photo
        self.bg_panel.pack(fill='both', expand='yes')
        # ====== Login Frame =========================
        self.lgn_frame = Frame(self.window, bg='#040405', width=950, height=600)
        self.lgn_frame.place(x=200, y=70)

        # ========================================================================
        # ========================================================
        # ========================================================================


        # ========================================================================
        # ============ Left Side Image ================================================
        # ========================================================================
        self.side_image = Image.open('R (2).png')
        photo = ImageTk.PhotoImage(self.side_image)
        self.side_image_label = Label(self.lgn_frame, image=photo, bg='#040405')
        self.side_image_label.image = photo
        self.side_image_label.place(x=5, y=100)

        # ========================================================================
        # ============ Sign In Image =============================================
        # ========================================================================
        # self.sign_in_image = Image.open('hyy.png')
        # photo = ImageTk.PhotoImage(self.sign_in_image)
        # self.sign_in_image_label = Label(self.lgn_frame, image=photo, bg='#040405')
        # self.sign_in_image_label.image = photo
        # self.sign_in_image_label.place(x=620, y=130)

        # ========================================================================
        # ============ Sign In label =============================================
        # ========================================================================
        self.sign_in_label = Label(self.lgn_frame, text="Student's Login Page", bg="black", fg="#00FFAB",
                                    font=("monospace", 35, "bold"))
        self.sign_in_label.place(x=50, y=60)

        # ========================================================================
        # ============================username====================================
        # ========================================================================
        self.username_label = Label(self.lgn_frame, text="Username", bg="black", fg="#FF6F91",
                                    font=("yu gothic ui", 19, "bold"))
        self.username_label.place(x=300, y=200)

        self.username_entry = Entry(self.lgn_frame, highlightthickness=0, relief=FLAT, bg="white", fg="black",
                                    font=("yu gothic ui ", 15, "bold"))
        self.username_entry.place(x=450, y=205, width=270)
        self.username_entry.focus()


        # ===== Username icon =========

        # ========================================================================
        # ============================login button================================
        # ========================================================================
        self.login = Button(self.lgn_frame, command=self.login_for_student, text='LOGIN', font=("yu gothic ui", 13, "bold"), width=25, bd=0,
                            bg='#00C9A7', cursor='hand2', activebackground='#3047ff', fg='white')
        self.login.place(x=490, y=350,width=120,height=40)
        # ========================================================================
        # ============================Forgot password=============================
        # ========================================================================
        self.forgot_button = Button(self.lgn_frame, text="Forgot Password ?",command=self.Forgot_Pass,
                                    font=("yu gothic ui", 13, "bold "), fg="black",bg="#FFA500",
                                    activebackground="blue"
                                    , borderwidth=0, cursor="hand2")
        self.forgot_button.place(x=330, y=410)
        # =========== Sign Up ==================================================
        # self.sign_label = Label(self.lgn_frame, text='No account yet?', font=("yu gothic ui", 13, "bold"),
        #                         relief=FLAT, borderwidth=0, background="#1E90FF", fg='white')
        # self.sign_label.place(x=500, y=418)

        # self.signup_img = ImageTk.PhotoImage(file='register.png')
        self.signup_button_label = Button(self.lgn_frame, command=lambda :self.window.destroy(),text="Back",font=("yu gothic ui",13,"bold") ,bg='#FFA500', cursor="hand2",
                                          borderwidth=0, activebackground="black",fg='black')
        self.signup_button_label.place(x=650, y=410, width=111, height=35)

        # ========================================================================
        # ============================password====================================
        # ========================================================================
        self.password_label = Label(self.lgn_frame, text="Password", bg="black", fg="#FF6F91",
                                    font=("yu gothic ui", 18, "bold"))
        self.password_label.place(x=300, y=280)


        self.password_entry = Entry(self.lgn_frame, highlightthickness=0, relief=FLAT, bg="white", fg="black",
                                    font=("yu gothic ui", 13, "bold"), show="*")
        self.password_entry.place(x=450, y=290, width=270)

        # ======== Password icon ================
        # ========= show/hide password ==================================================================
        self.show_image = ImageTk.PhotoImage \
            (file='show.png')

        self.hide_image = ImageTk.PhotoImage \
            (file='hide.png')

        self.show_button = Button(self.lgn_frame, image=self.show_image, command=self.show, relief=FLAT,
                                  activebackground="white"
                                  , borderwidth=0, background="white", cursor="hand2")
        self.show_button.place(x=730, y=295)


    def show(self):
        self.hide_button = Button(self.lgn_frame, image=self.hide_image, command=self.hide, relief=FLAT,
                                  activebackground="white"
                                  , borderwidth=0, background="white", cursor="hand2")
        self.hide_button.place(x=730, y=295)
        self.password_entry.config(show='')

    def hide(self):
        self.show_button = Button(self.lgn_frame, image=self.show_image, command=self.show, relief=FLAT,
                                  activebackground="white"
                                  , borderwidth=0, background="white", cursor="hand2")
        self.show_button.place(x=730, y=295)
        self.password_entry.config(show='*')

    def login_for_student(self):
        global x_username
        x_username=self.username_entry.get()
        if self.username_entry.get() == "" or self.password_entry.get() == "":
            messagebox.showerror("OOPS!!", "Username and Password Must be required")
        else:
            try:
                con = pymysql.connect(host='localhost', user='root', password='0000', database='project')
                cur = con.cursor()
                cur.execute('select * from student where eroll=%s and pass=%s', (self.username_entry.get(), self.password_entry.get()))
                row = cur.fetchone()
                if row == None:
                    messagebox.showerror("Error", "Invalid UserNmae or Password", parent=self.window)
                    self.password_entry.delete(0, END)
                    self.username_entry.focus()
                else:
                    self.Student_Login()
                    self.password_entry.delete(0, END)
                    self.password_entry.focus()
                    con.close()

            except Exception as es:
                messagebox.showerror('Error', f'Error Due to : {str(es)}', parent=self.window)


    def Forgot_Pass(self):
        try:
            if self.username_entry.get() == "":
                messagebox.showerror('Error', 'User Must Enter its Username')
            else:
                con = pymysql.connect(host='localhost', user='root', password='0000', database='project')
                cur = con.cursor()
                cur.execute('select eroll from student where eroll=%s', self.username_entry.get())
                row = cur.fetchone()
                if row == None:
                    messagebox.showerror("Error", "Enterd UserName Not Contained in our Database", parent=self.window)
                else:
                    self.root2 = Toplevel()
                    self.root2.title("Forgot Password")
                    self.root2.geometry("440x800+0+0")
                    l = Label(self.root2, text="Forgot Password", font=("monospace", 15, "bold"))
                    l.place(x=10, y=30, relwidth=1)
                    SelQue = Label(self.root2, text="Select Question", font=("times new roman", 14, "bold"),
                                   bg="white")
                    SelQue.place(x=50, y=100)
                    self.Rcombo_que = ttk.Combobox(self.root2, font=("times new roman", 14, "bold"), state="readonly")
                    self.Rcombo_que["values"] = ("Select", "your Birth Place?", "Your Pet Name?", "Your Birth Year?")
                    self.Rcombo_que.place(x=50, y=130, width=225)
                    self.Rcombo_que.current(0)
                    SelAns = Label(self.root2, text="Answer", font=("times new roman", 17, "bold"), bg="white",
                                   fg="black")
                    SelAns.place(x=50, y=190)
                    self.RSelAns = ttk.Entry(self.root2, font=("monospace", 15, "italic"))
                    self.RSelAns.place(x=50, y=220)
                    self.Butt = Button(self.root2, command=self.forgot_thing, text="Check",
                                       font=("monospace", 14, "bold"), foreground="green",
                                       background="yellow")
                    self.Butt.place(x=130, y=300, width=100)
                    con.commit()
                    con.close()
        except EXCEPTION as es:
            messagebox.showerror("Error", f"Error due to {str(es)}", parent=self.root2)


    def forgot_thing(self):
        try:


            con = pymysql.connect(host='localhost', user='root', password='0000', database='project')
            cur = con.cursor()
            cur.execute('select SEQQ from student where eroll=%s', self.username_entry.get())
            row = cur.fetchone()
            cur.execute('select SEQA from student where eroll=%s', self.username_entry.get())
            row1 = cur.fetchone()
            con.commit()
            con.close()
            if self.Rcombo_que.get() == "Select" or self.RSelAns.get() == "":
                messagebox.showerror("Error", "All fields are Mandatory!!", parent=self.window)
            elif self.RSelAns.get() != row1[0]:
                messagebox.showerror("Error", "Wrong Sequrity Answer", parent=self.window)
            else:
                self.password_entry.insert(0, row1[0])
                messagebox.showinfo("Success", "Now You can Login!", parent=self.window)
                self.root2.destroy()
        except EXCEPTION as es:
            messagebox.showerror("Error", f"Error due to {str(es)}", parent=self.window)
    def Student_Login(self):
        self.new_win=Toplevel(self.window)
        self.app=Student_Dashboard(self.new_win)



class Student_Dashboard:
    def __init__(self,root):
        self.root=root
        self.root.geometry("1530x790+0+0")
        self.root.title("Student DashBoard")
        img=Image.open(r"butterfly_PNG1053.png")
        img=img.resize((1450,800),Image.ANTIALIAS)
        self.photoimg=ImageTk.PhotoImage(img)

    #Overall Background Image
        f_lbl=Label(self.root,bg='#FF7396')
        f_lbl.place(x=0,y=0,width=1500,height=800)
    #Overall Titile
        title_lbl=Label(f_lbl,text="Student's DashBoard",font=("times new roman",36,"bold underline"),bg="#FF7396")
        title_lbl.place(x=490,y=20)
    #Main frame
        main_frame=Frame(f_lbl,bd=2,bg='#FF7396')
        main_frame.place(x=20,y=90,width=1500,height=800)
    #Label Frame
        Left_frame=LabelFrame(main_frame,bd=2,relief=RIDGE,text="Modify Your Details",font=("times new roman",13,"bold"),bg='#4FFBDF')
        Left_frame.place(x=10,y=10,width=460,height=580)
    #Right frame for showing Absent and Present
        Right_frame=LabelFrame(main_frame,bd=2,relief=RIDGE,text="Attendence Status",font=("times new roamn",12,"bold"))
        Right_frame.place(x=900,y=10,width=340,height=580)
    #roll no
        Email = Label(Left_frame, text="Exam Roll NO",background='#4FFBDF', font=("monospace", 13, "bold"))
        Email.place(x=10, y=10)

        self.Exam_roll = ttk.Entry(Left_frame,font=("times new roman", 12, "bold"))

        self.Exam_roll.place(x=210, y=10)
        self.Exam_roll.insert(0,x_username)
        self.Exam_roll.configure(state='readonly')


        roll_no = Label(Left_frame, text="Email", bg='#4FFBDF',font=("monospace", 13, "bold"))
        roll_no.place(x=10, y=80)
        self.Email_entry = ttk.Entry(Left_frame, font=("times new roman", 12, "bold"))
        self.Email_entry.place(x=210, y=80)
        roll_no = Label(Left_frame, text="Name",bg='#4FFBDF', font=("monospace", 13, "bold"))
        roll_no.place(x=10, y=160)
        self.Name_entry = ttk.Entry(Left_frame, font=("times new roman", 12, "bold"))
        self.Name_entry.place(x=210, y=160)
        roll_no = Label(Left_frame, text="Phone",bg='#4FFBDF', font=("monospace", 13, "bold"))
        roll_no.place(x=10, y=240)
        self.Phone_Entry = ttk.Entry(Left_frame, font=("times new roman", 12, "bold"))
        self.Phone_Entry.place(x=210, y=240)


        Semester = Label(Left_frame, text="Department",background='#4FFBDF' ,font=("monospace", 13, "bold"))
        Semester.place(x=10, y=320)
        self.StuComDept = ttk.Combobox(Left_frame, font=("times new roman", 15, "bold"), state="readonly")
        self.StuComDept.place(x=210, y=320, width=200)
        self.StuComDept["values"] = ("Select", "Bsc CA", "Bsc IT")
        self.StuComDept.configure(state='readonly')

        roll_no = Label(Left_frame, text="Semester",bg='#4FFBDF', font=("monospace", 13, "bold"))
        roll_no.place(x=10, y=400)

        self.StuSem = ttk.Combobox(Left_frame, font=("times new roman", 15, "bold"), state="readonly")
        self.StuSem.place(x=210, y=400, width=200)
        self.StuSem["values"] = ("Select", "SEM I", "SEM II", "SEM III", "SEM IV", "SEM V", "SEM VI")
        self.StuSem.current(0)


        save_btn=Button(Left_frame,command=self.Update,text="Save",font=("times new roman",12,"bold"))
        save_btn.place(x=10,y=500,height=40,width=150)
        clear_btn=Button(Left_frame,command=self.clear,text="Clear",font=("times new roman",12,"bold"))
        clear_btn.place(x=170,y=500,height=40,width=150)

        scroll_x=ttk.Scrollbar(Right_frame,orient=HORIZONTAL)
        scroll_y=ttk.Scrollbar(Right_frame,orient=VERTICAL)

        self.StatusTable=ttk.Treeview(Right_frame,columns=("Pre","Tim"),xscrollcommand=scroll_x.set,yscrollcommand=scroll_y.set)
        scroll_y.pack(side=RIGHT,fill=Y)
        scroll_x.pack(side=BOTTOM,fill=X)
        scroll_x.config(command=self.StatusTable.xview)
        scroll_y.config(command=self.StatusTable.yview)
        clear_btn = Button(f_lbl, command=lambda :self.root.destroy(), text="Sign Out", font=("times new roman", 15, "bold"),border=1,foreground="black")
        clear_btn.place(x=1130, y=10, height=40, width=150)
        result=self.Average()

        the_Av = Label(main_frame, font=("times new roman", 27, "bold"), background='#FF7396', foreground='navy',
                       text=("Attendance Percentage\n"+str(result))+"%")
        the_Av.place(x=509, y=100)

        self.StatusTable.heading("Pre",text="Present")
        self.StatusTable.heading("Tim",text="Time")
        self.StatusTable["show"]="headings"
        self.StatusTable.column("Pre",width=100)
        self.StatusTable.column("Tim",width=100)
        self.StatusTable.pack(fill=BOTH,expand=1)
        self.autoShow()
        self.auto()
    def Average(self):
        try:
            con = pymysql.connect(host='localhost', user='root', password='0000', database='project')
            cur = con.cursor()
            cur.execute('select count(*) from attendence where eroll=%s and month(date)=%s', (x_username, date.today().month), )
            x1 = cur.fetchone()
            cur.execute('select count(distinct(date)) from attendence where month(date)=%s', date.today().month)
            y1 = cur.fetchone()
            con.commit()
            con.close()
            if x1[0]==0 or y1[0]==0:
                return 0
            else:
                return (x1[0]/y1[0])*100;
        except Exception as es:
            messagebox.showerror("Error", f"Error due to {str(es)}")



    def auto(self):
        try:
            con = pymysql.connect(host="localhost", user="root", password="0000", database="project")
            cur = con.cursor()
            cur.execute("select DATE,TIME from attendence where attend='P' and eroll=%s", x_username)
            data = cur.fetchall()
            if len(data) != 0:
                self.StatusTable.delete(*self.StatusTable.get_children())
                for i in data:
                    self.StatusTable.insert("", END, values=i)
            else:
                messagebox.showinfo("Error","Enpty",parent=self.root)
            con.commit()
            con.close()
        except Exception as e:
            messagebox.showerror("Error", f"error due to {str(e)}:", parent=self.root)
    def Update(self):
        try:
            if self.Exam_roll.get()=="" or self.StuSem.get()=="Select" or self.StuComDept.get()=="Select" or self.Email_entry.get()=="":
                messagebox.showerror("Error","Fields must be required ",parent=self.root)
            else:
                con = pymysql.connect(host="localhost", user="root", password="0000", database="project")
                cur = con.cursor()
                cur.execute("update STUDENT set NAME=%s,EMAIl=%s ,PHONE=%s,DEPT=%s,SEM=%s where EROLL=%s", (self.Name_entry.get(), self.Email_entry.get(), self.Phone_Entry.get(), self.StuComDept.get(),self.StuSem.get(), x_username) ,)
                con.commit()
                con.close()
                messagebox.showinfo("Success!!!","Data Inserted Successfully!!",parent=self.root)
        except Exception as e:
            messagebox.showerror("Error", f"error due to{str(e)}", parent=self.root)

    def autoShow(self):
        try:
            con=pymysql.connect(host="localhost",user="root",password="0000",database="project")
            cur=con.cursor()
            cur.execute("select email,name,phone,dept,sem from student where eroll=%s",str(x_username))
            data=cur.fetchall()
            self.Exam_roll.insert(0,x_username)
            self.Email_entry.insert(0,data[0][0])
            self.Name_entry.insert(0,data[0][1])
            self.Phone_Entry.insert(0,data[0][2])
            if data[0][3]=="Bsc CA":
                self.StuComDept.current(1)
            else:
                self.StuComDept.current(2)
            if data[0][4]=="SEM I":
                self.StuSem.current(1)
            elif data[0][4]=="SEM II":
                self.StuSem.current(2)
            elif data[0][4]=="SEM III":
                self.StuSem.current(3)
            elif data[0][4]=="SEM IV":
                self.StuSem.current(4)
            elif data[0][4]=="SEM V":
                self.StuSem.current(5)
            else:
                self.StuSem.current(6)



        except Exception as e:
            messagebox.showerror("Error",f"error due to{str(e)}",parent=self.root)
    def clear(self):
        self.StuSem.current(0)
        self.Exam_roll.delete(0,END)
        self.StuComDept.current(0)
        self.StuComDept.current(0)
        self.StuSem.current(0)
        self.Email_entry.delete(0,END)
        self.Name_entry.delete(0,END)
        self.Phone_Entry.delete(0,END)











if __name__ == '__main__':
    window = Tk()
    app=Student_Login_Page(window)
    window.mainloop()