from tkinter import *
from tkinter import messagebox
from tkinter import ttk

import pymysql
from PIL import ImageTk
from tkcalendar import DateEntry


# from pymysql import *


class Student:
    def __init__(self, root):
        self.root = root
        self.root.title("Login")
        self.root.geometry("1550x800+0+0")
        self.root.resizable(True, False)
        # Main Frame
        Frame_login1 = Frame(self.root, bg="black")
        Frame_login1.place(x=0, y=0, height=700, width=1550)

        self.img = ImageTk.PhotoImage(file="feather-focus-blur-sunset-5k-yv.jpg", size=0.5)
        # SEcond Main Frame
        img = Label(Frame_login1, image=self.img).place(x=0, y=0, width=1550, height=700)
        frame_imput2 = Frame(self.root, bg='white')
        frame_imput2.place(x=300, y=130, height=600, width=800)
        #  Heading
        label1 = Label(frame_imput2, text="Student Registration Form", font=('monospace', 32, 'bold'), fg="black",
                       bg="white")
        label1.place(x=45, y=20)
        # Exam Roll NO
        label2 = Label(frame_imput2, text="Exam Roll Number", font=("goudy old style", 17, "bold"), fg="orangered",
                       bg="white")
        label2.place(x=50, y=90)
        # Exam Roll NO TAKING BOX~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
        self.Sturoll = Entry(frame_imput2, font=("monospace", 15, "bold"), bg="lightgray")
        self.Sturoll.place(x=50, y=130, width=250, height=30)
        # Name ###########################################
        label03 = Label(frame_imput2, text=" FullName", font=("goudy old style", 17, "bold"), fg="orangered",
                        bg="white")
        label03.place(x=50, y=165)
        # FOR FIRST NAME################################
        self.Stuname = Entry(frame_imput2, font=("monospace", 15, "bold"), bg="lightgray", fg="black")
        self.Stuname.place(x=50, y=200, width=250, height=30)
        # Phone ###########################################
        label04 = Label(frame_imput2, text="Phone", font=("goudy old style", 17, "bold"), fg="orangered",
                        bg="white")
        label04.place(x=350, y=165)
        #  TEXT box Phone ################################
        self.Stuph = Entry(frame_imput2, font=("monospace", 15, "bold"), bg="lightgray", fg="black")
        self.Stuph.place(x=350, y=200, width=250, height=30)
        ###################################LABEL THREE FOR NAME ###########################################
        label05 = Label(frame_imput2, text="E-Mail-ID", font=("goudy old style", 17, "bold"), fg="orangered",
                        bg="white")
        label05.place(x=355, y=90)
        # EMail ################################
        self.Stumail = Entry(frame_imput2, font=("monospace", 15, "bold"), bg="lightgray", fg="black")
        self.Stumail.place(x=350, y=130, width=250, height=30)
        # PASSWORD #################################
        Stulabel05 = Label(frame_imput2, text="Password", font=("monospace", 17, "bold"), fg="orangered", bg="white")
        Stulabel05.place(x=50, y=375)
        # ENTRY BOX FOr password ################################
        self.Stupass = Entry(frame_imput2, font=("monospace", 15, "bold"), bg="lightgray", fg="black")
        self.Stupass.place(x=50, y=415, width=250, height=30)
        # Re #nter passwod#
        Reglabel05 = Label(frame_imput2, text="ReEnter Password", font=("goudy old style", 17, "bold"), fg="orangered",
                           bg="white")
        Reglabel05.place(x=350, y=375)
        # REenter Password
        self.StuConPass = Entry(frame_imput2, font=("monospace", 15, "bold"), bg="lightgray", fg="black")
        self.StuConPass.place(x=350, y=415, width=250, height=30)

        # Button for inserting data to Teacher database~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
        self.REGButton = Button(frame_imput2, text="Register", cursor="hand2", command=self.Stu_register,
                                font=("times new roman", 15, "bold"), activebackground="orangered", fg="white",
                                bg="orangered", bd=0, width=15, height=1)
        self.REGButton.place(x=600, y=500, width=200)
        # Combobox for Dept
        Reglabel05 = Label(frame_imput2, text="Department", font=("goudy old style", 17, "bold"), fg="orangered",
                           bg="white")
        Reglabel05.place(x=50, y=235)

        self.StuComDept = ttk.Combobox(frame_imput2, font=("times new roman", 15, "bold"), state="readonly")
        self.StuComDept.place(x=50, y=270, width=225)
        self.StuComDept["values"] = ("Select", "Bsc.Ca", "Bsc It")
        self.StuComDept.current(0)
        # Semester U are IN
        Reglabel05 = Label(frame_imput2, text="Semester", font=("goudy old style", 17, "bold"), fg="orangered",
                           bg="white")
        Reglabel05.place(x=350, y=235)
        # Semester Combobox
        self.StuSem = ttk.Combobox(frame_imput2, font=("times new roman", 15, "bold"), state="readonly")
        self.StuSem.place(x=350, y=270, width=225)
        self.StuSem["values"] = ("Select", "SEM-I", "SEM-II", "SEM-III", "SEM-III", "SEM-IV", "SEM-V", "SEM-VI")
        self.StuSem.current(0)
        # BirthDate
        Reglabel05 = Label(frame_imput2, text="Birth-Date", font=("goudy old style", 17, "bold"), fg="orangered",
                           bg="white")
        Reglabel05.place(x=50, y=305)
        # BirthDate Entry
        self.Stucal = DateEntry(frame_imput2, width=12, year=2022, month=1, font=("times new roman", 10, "bold"), day=1,
                                background='darkblue', foreground='white', borderwidth=2)
        self.Stucal.place(x=50, y=335, width=223)

        # Gender
        Reglabel05 = Label(frame_imput2, text="Gender", font=("goudy old style", 17, "bold"), fg="orangered",
                           bg="white")
        Reglabel05.place(x=350, y=300)
        self.StuGen = ttk.Combobox(frame_imput2, font=("times new roman", 15, "bold"), state="readonly")
        self.StuGen.place(x=350, y=340, width=225)
        self.StuGen["values"] = ("Select", "Male", "Female", "Other")
        self.StuGen.current(0)
        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~Button for Back~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
        self.StuBackButton = Button(frame_imput2, text="Back", cursor="hand2", font=("times new roman", 15, "bold"),
                                    activebackground="orangered", fg="white", bg="orangered", bd=0, width=15, height=1)

        self.StuBackButton.place(x=600, y=50, width=200)

    def Stu_register(self):
        if self.Sturoll.get() == "" or self.Stumail.get() == "" or self.Stuname.get() == "" or self.Stuph.get() == "" or self.StuComDept.get() == "Select" or self.StuGen.get() == "Select" or self.Stupass.get() == "" or self.StuConPass.get() == "" or self.Stucal.get() == "1-1-2022":
            messagebox.showerror("Error", "All Fields Must be Filled!!", parent=self.root)
        elif self.Stupass.get() != self.StuConPass.get():
            messagebox.showerror("Error", "Entered Password are Diffrent", parent=self.root)
        else:
            try:
                con = pymysql.connect(host="localhost", user="root", password="0000", database="project")
                cur = con.cursor()
                cur.execute("select * from student where EMAIL=%s", self.Stumail.get())
                row = cur.fetchone()
                cur1 = con.cursor()
                cur1.execute("select EROLL from student where EROLL=%s", self.Sturoll.get())
                row1 = cur1.fetchone()
                if row != None:
                    messagebox.showerror("Error", "Email Address is Already Registred!!", parent=self.root)
                    self.Stumail.delete(0, END)
                    self.Stumail.focus()
                elif row1 != None:
                    messagebox.showerror("Error", "Enter RollNumber is Already Registered!!", parent=self.root)
                    self.Sturoll.delete(0, END)
                    self.Sturoll.focus()
                else:
                    cur2 = con.cursor()
                    cur2.execute(
                        " insert into student (EROLL,EMAIL,NAME,PHONE,DEPT,SEM,BIRTH,GEN,PASS)values(%s,%s,%s,%s,%s,%s,%s,%s,%s)",
                        (
                            self.Sturoll.get(), self.Stumail.get(), self.Stuname.get(), self.Stuph.get(),
                            self.StuComDept.get(), self.StuSem.get(), self.Stucal.get(), self.StuGen.get(),
                            self.Stupass.get()))
                    con.commit()
                    con.close()
                    messagebox.showinfo("Registred", "redirecting to home!!", parent=self.root)
                    self.root.destroy()
            except Exception as es:
                messagebox.showerror("Error", f"Erorr due to {str(es)}:", parent=self.root)


if __name__ == "__main__":
    root = Tk()
    app = Student(root)
    root.mainloop()
