from tkinter import *
from tkinter import messagebox
from tkinter import ttk, StringVar
import glob
import os
import os.path
import cv2
import numpy as np
import pymysql
from PIL import Image, ImageTk
from tkcalendar import DateEntry


class Teachers_Dashboard:

    def __init__(self, root):
        self.root = root
        self.root.title("Register")
        self.root.geometry("1400x750+0+0")
        # Variable Declearation
        self.var_Roll = StringVar()
        self.var_Name = StringVar()
        self.var_Phone = StringVar()
        self.var_Email = StringVar()
        self.var_Gen = StringVar()
        self.var_Sem = StringVar()
        self.var_bithday = StringVar()
        self.var_Dept = StringVar()
        self.var_AborPr = StringVar()
        self.var_Date = StringVar()

        img = Image.open(f"df939a9cb83d0691bf39acc35ef73af9.jpg")
        img = img.resize((1550, 700), Image.Resampling.LANCZOS)
        self.photoimg3 = ImageTk.PhotoImage(img)
        bg_Img = Label(self.root, image=self.photoimg3)
        bg_Img.place(x=0, y=0, width=1550, height=700)
        labelHead = Label(self.root, text="Welcome", font=("monospace", 42, "bold"), fg="cyan", bg="#6082b6")
        labelHead.place(x=5, y=5, height=40, width=300)
        # mainframe
        main_frame = Frame(bg_Img, bd=2)
        main_frame.place(x=20, y=50, width=1550, height=600)
        # Optino Pane
        Left_frame = LabelFrame(main_frame, bg="aqua", bd=2, relief=RIDGE, text="Options",
                                font=("times new roman", 12, "bold"))
        Left_frame.place(x=10, y=10, width=510, height=580)
        # Query Pane
        Query_frame = LabelFrame(main_frame, bd=2, bg="magenta", relief=RIDGE, text="Query DashBoard",
                                 font=("times new roman", 12, "bold"))
        Query_frame.place(x=530, y=10, width=800, height=580)
        # Welcom Labl
        welcome_lbl = Label(Left_frame, text="Welcome Mr.", font=("monospace", 12, "bold"), bg="aqua")
        welcome_lbl.place(x=10, y=8)
        # Dept Label
        Dept_Label = Label(Left_frame, text="Department.", font=("monospace", 11, "bold"), bg="aqua")
        Dept_Label.place(x=20, y=50)
        # Dept Combo
        self.H_dept = ttk.Combobox(Left_frame, textvariable=self.var_Dept, font=("monospace", 12, "bold"), width=17,
                                   state="readonly")
        self.H_dept["values"] = ("Select ", "Bsc CA", "Bsc IT")
        self.H_dept.current(0)
        self.H_dept.place(x=220, y=50)
        # Sem
        H_Sem = Label(Left_frame, bd=2, bg="aqua", text="Select Semester", font=("monospace", 11, "bold"))
        H_Sem.place(x=20, y=105)
        # Sem Com
        self.H_SEM = ttk.Combobox(Left_frame, textvariable=self.var_Sem, font=("monospace", 12, "bold"), width=17,
                                  state="readonly", background="cyan")
        self.H_SEM["values"] = ("Select", "SEM I", "SEM II", "SEM III", "SEM IV", "SEM V", "SEM VI")
        self.H_SEM.current(0)
        self.H_SEM.place(x=220, y=105)
        # Absent/Present Label
        H_AbLab = Label(Left_frame, bd=2, bg="aqua", text="Absent/Present", font=("monospace", 11, "bold"))
        H_AbLab.place(x=20, y=160)
        # Absent/ Present
        self.H_Aborp = ttk.Combobox(Left_frame, textvariable=self.var_AborPr, font=("monospace", 12, "bold"), width=17,
                                    state="readonly", background="cyan")
        self.H_Aborp["values"] = ("Select", "Absent", "Present")
        self.H_Aborp.current(0)
        self.H_Aborp.place(x=220, y=160)
        # Late/Ontime
        H_AorP = Label(Left_frame, bd=2, bg="aqua", text="Late/Ontime", font=("monospace", 11, "bold"))
        H_AorP.place(x=20, y=220)

        self.H_LateorT = ttk.Combobox(Left_frame, textvariable=self.var_Date, font=("monospace", 12, "bold"), width=17,
                                      state="readonly", background="cyan")
        self.H_LateorT["values"] = ("Select", "Late", "Ontime")
        self.H_LateorT.current(0)
        self.H_LateorT.place(x=220, y=220)
        # Date
        H_CalLab = Label(Left_frame, bd=2, bg="aqua", text="Date", font=("monospace", 11, "bold"))
        H_CalLab.place(x=20, y=280)
        # Date imput
        self.H_cal = DateEntry(Left_frame, width=12, calendar_cursor="hand2", font=("times new roman", 12, "bold"),
                               background='darkblue', foreground='white', borderwidth=2)
        self.H_cal.place(x=220, y=280, width=175)
        # Search with roll no
        Roll_frame = LabelFrame(Left_frame, bd=2, bg="cyan", relief=RIDGE, text="Search",
                                font=("times new roman", 12, "bold"))
        Roll_frame.place(x=10, y=420, width=490, height=55)
        # Enter Roll No
        H_EnterRoll = Label(Roll_frame, bd=2, bg="aqua", text="Exam-Roll-NO", font=("monospace", 11, "bold"))
        H_EnterRoll.place(x=00, y=0)
        # Roll NO Entery
        self.H_RollByHand = Entry(Roll_frame, textvariable=self.var_Roll, font=("monospace", 15, "bold"),
                                  bg="lightgray", fg="black")
        self.H_RollByHand.place(x=190, y=0, width=180, height=25)
        # Button For check
        REGButton = Button(Roll_frame, text="Check", cursor="hand2",command=self.showByHand,
                           font=("times new roman", 12, "bold"), activebackground="orangered", fg="white",
                           bg="orangered", bd=0, width=15, height=1)
        REGButton.place(x=380, y=0, width=100)
        # Logout Button
        H_Logout = Button(bg_Img, text="Logout", cursor="hand2", command=self.root.destroy,
                          font=("times new roman", 15, "bold"), activebackground="orangered", fg="black",
                          bg="orangered", activeforeground="white", bd=0, width=15, height=1)
        H_Logout.place(x=1200, y=9, width=150)
        # REset Button
        H_RestBtn = Button(Left_frame, text="Reset", cursor="hand2", command=self.ClearAll,
                           font=("times new roman", 12, "bold"), activebackground="orangered", fg="white",
                           bg="orangered", bd=0, width=15, height=1)
        H_RestBtn.place(x=380, y=360, width=100)
        # Manage Student
        H_MangeStu = Button(Left_frame, text="Manage Student", cursor="hand2",command=self.DeleteStudentAT,
                            font=("times new roman", 12, "bold"), activebackground="orangered", fg="white",
                            bg="orangered", bd=0, width=15, height=1)
        H_MangeStu.place(x=200, y=360, width=150)
        # Today's Report
        H_Tody = Button(Left_frame, text="Today's Attendence", command=self.changeToShowAT,cursor="hand2",
                        font=("times new roman", 12, "bold"), activebackground="orangered", fg="white",
                        bg="orangered", bd=0, width=15, height=1)
        H_Tody.place(x=20, y=360, width=140)
        # show Button
        showBtn = Button(Left_frame, text="Show", command=self.CheckData, font=("times new roman", 12, "bold"), bd=0,
                         fg="black", bg="orangered")
        showBtn.place(x=400, y=160, width=100, height=40)
        # Table Frame
        table_frame = Frame(Query_frame, bd=2, bg="white", relief=RIDGE)
        table_frame.place(x=5, y=10, width=790, height=540)
        # Scroll Bar
        scrool_x = ttk.Scrollbar(table_frame, orient=HORIZONTAL)
        scrool_y = ttk.Scrollbar(table_frame, orient=VERTICAL)

        # Table
        self.Student_Table = ttk.Treeview(table_frame, columns=("roll", "Na", "Ph", "mail", "time", "gen", "date"),
                                          xscrollcommand=scrool_x.set, yscrollcommand=scrool_y.set)
        scrool_x.pack(side=BOTTOM, fill=X)
        scrool_y.pack(side=RIGHT, fill=Y)
        scrool_y.config(command=self.Student_Table.yview)
        scrool_x.config(command=self.Student_Table.xview)
        self.Student_Table.heading("roll", text="Exam Roll No")
        self.Student_Table.heading("Na", text="Name")
        self.Student_Table.heading("Ph", text="Phone")
        self.Student_Table.heading("mail", text="Email-ID")
        self.Student_Table.heading("time", text="Time")
        self.Student_Table.heading("gen", text="Gender")
        self.Student_Table.heading("date", text="Date")
        self.Student_Table['show'] = "headings"
        self.Student_Table.column("roll", width=100, minwidth=100, )
        self.Student_Table.column("Na", width=100, minwidth=100)
        self.Student_Table.column("Ph", width=100, minwidth=100)
        self.Student_Table.column("mail", width=100, minwidth=100)
        self.Student_Table.column("time", width=100, minwidth=100)
        self.Student_Table.column("gen", width=100, minwidth=100)
        self.Student_Table.column("date", width=100, minwidth=100)
        self.Student_Table.pack(fill=BOTH, expand=1)

    # Clear Things

    def ClearAll(self):
        self.H_dept.current(0)
        self.H_SEM.current(0)
        self.H_Aborp.current(0)
        self.H_cal.delete(0, END)
        self.H_cal.insert(0, "Enter Date")
        self.H_LateorT.current(0)
        self.H_RollByHand.delete(0, END)
        self.Student_Table.delete(*self.Student_Table.get_children())

    # Adding and Showing Data
    def CheckData(self):
        if self.H_Aborp.get() == "Select" or self.H_dept.get() == "Select" or self.H_SEM == "Select" or self.H_LateorT == "Select":
            messagebox.showerror("Error", "Selection Not Valid", parent=self.root)
        else:
            try:
                if self.H_Aborp.get() == "Present":
                    self.Student_Table.delete(*self.Student_Table.get_children())
                    conn = pymysql.connect(host="localhost", user="root", password="0000", database="project")
                    curr = conn.cursor()
                    curr.execute(
                        "select EROLL,NAME,PHONE,MAIL,TIME,GEN ,DATE from Attendence where   SEM=%s and DATE=%s and DEPT=%s",
                        (self.H_SEM.get(), self.H_cal.get_date(),self.H_dept.get()))
                    values = curr.fetchall()
                    if len(values) == 0:
                        messagebox.showerror("Error", "Empty", parent=self.root)
                    else:
                        for i in values:
                            self.Student_Table.insert("", END, values=i)
                else:
                    self.Student_Table.delete(*self.Student_Table.get_children())
                    conn = pymysql.connect(host="localhost", user="root", password="0000", database="project")
                    curr = conn.cursor()
                    curr.execute(
                        "select eroll ,name,phone,email,\"Absent\",gen,curdate() from student where sem=%s and dept=%s and eroll not in(select eroll from attendence where date=%s)",
                        (self.H_SEM.get(), self.H_dept.get(),self.H_cal.get_date()))
                    values = curr.fetchall()
                    if len(values) == 0:
                        messagebox.showerror("Error", "Empty", parent=self.root)
                    else:
                        for i in values:
                            self.Student_Table.insert("", END, values=i)

                    conn.commit()
                    conn.close()
            except Exception as es:
                messagebox.showerror("Error", f"error due to:{str(es)}", parent=self.root)
    def changeToShowAT(self):
        self.new_win = Toplevel(self.root)
        self.app = Today_attendence(self.new_win)
    def DeleteStudentAT(self):
        self.ClearAll()
        self.new_del=Toplevel(self.root)
        self.app=Manage_Student(self.new_del)
    def showByHand(self):
        self.Student_Table.delete(*self.Student_Table.get_children())
        try:
            conn = pymysql.connect(host="localhost", user="root", password="0000", database="project")
            curr = conn.cursor()
            curr.execute(
                "select EROLL,NAME,PHONE,MAIL,TIME,GEN ,DATE from Attendence where   eroll=%s",
                (self.var_Roll.get()))
            values = curr.fetchall()
            if len(values) == 0:
                messagebox.showerror("Error", "Not Valid Roll no!!", parent=self.root)
            else:
                for i in values:
                    self.Student_Table.insert("", END, values=i)
            conn.commit()
            conn.close()
        except Exception as es:
            messagebox.showerror("Error", f"error due to:{str(es)}", parent=self.root)
class Manage_Student:
    def __init__(self, root):
        self.root = root
        self.root.title("Manage Student")
        self.root.geometry("800x750+0+0")
        bg_Img = Label(self.root, background="#FF6F91")
        bg_Img.place(x=0, y=0, width=800, height=700)
        UpperLabel = Label(bg_Img, background="#FEF7FF")
        UpperLabel.place(x=10, y=50, width=750, height=500)
        showBtn = Button(bg_Img, text="Back", command=lambda: self.root.destroy(), font=("times new roman", 12, "bold"),
                         bd=0,
                         fg="black", bg="white")
        showBtn.place(x=600, y=600, width=100, height=40)
        DelBtn = Button(bg_Img, text="Delete", font=("times new roman", 12, "bold"),
                        command=self.get_cursor,
                         bd=0,
                         fg="black", bg="white")
        DelBtn.place(x=400, y=600, width=100, height=40)
        # Scroll Bar
        scrool_x = ttk.Scrollbar(UpperLabel, orient=HORIZONTAL)
        scrool_y = ttk.Scrollbar(UpperLabel, orient=VERTICAL)
        # Table
        self.TableTODel = ttk.Treeview(UpperLabel, columns=("roll", "Na", "Ph", "mail", "dep","gen"),
                                       xscrollcommand=scrool_x.set, yscrollcommand=scrool_y.set)
        scrool_x.pack(side=BOTTOM, fill=X)
        scrool_y.pack(side=RIGHT, fill=Y)
        scrool_y.config(command=self.TableTODel.yview)
        scrool_x.config(command=self.TableTODel.xview)
        self.TableTODel.heading("roll", text="Exam Roll No")
        self.TableTODel.heading("Na", text="Name")
        self.TableTODel.heading("Ph", text="Phone")
        self.TableTODel.heading("mail", text="Email-ID")
        self.TableTODel.heading("dep",text="Department")
        self.TableTODel.heading("gen", text="Gender")
        self.TableTODel['show'] = "headings"
        self.TableTODel.column("roll", width=100, minwidth=100, )
        self.TableTODel.column("Na", width=100, minwidth=100)
        self.TableTODel.column("Ph", width=100, minwidth=100)
        self.TableTODel.column("mail", width=100, minwidth=100)
        self.TableTODel.column("dep",width=100,minwidth=100)
        self.TableTODel.column("gen", width=100, minwidth=100)
        self.TableTODel.pack(fill=BOTH, expand=1)
        self.autoShowToDel()

    def autoShowToDel(self):
        try:
            self.TableTODel.delete(*self.TableTODel.get_children())
            conn = pymysql.connect(host="localhost", user="root", password="0000", database="project")
            curr = conn.cursor()
            curr.execute(
                "select EROLL,NAME,PHONE,Email,dept,Gen from student ")
            values = curr.fetchall()
            if len(values) == 0:
                messagebox.showerror("Error", "No Registered Student Found!!", parent=self.root)
            else:
                for i in values:
                    self.TableTODel.insert("", END, values=i)
            conn.commit()
            conn.close()
        except Exception as es:
            messagebox.showerror("Error", f"error due to:{str(es)}", parent=self.root)
    def get_cursor(self):
        cursor_focus=self.TableTODel.focus()
        content=self.TableTODel.item(cursor_focus)
        data=content["values"]
        try:
            if(data[0]is not None):
                try:
                    conn = pymysql.connect(host="localhost", user="root", password="0000", database="project")
                    curr = conn.cursor()
                    curr.execute("delete from student where eroll=%s  ", data[0])
                    curr.execute("delete from attendence where eroll=%s", data[0])
                    files = glob.glob('Data/user.'+str(data[0])+'*.jpg')
                    for i in files:
                        os.remove(i)
                    self.Classifier_after_Delete()
                    messagebox.showinfo("Info","Data Successfully Deleted!!",parent=self.root)
                    curr.execute("select count(*) from student")
                    after_data=curr.fetchone()
                    conn.commit()
                    conn.close()
                    self.autoShowToDel()
                except Exception as E:
                    messagebox.showerror("Error",f"error due to{str(E)}:",parent=self.root)
        except Exception as es:
            messagebox.showinfo("Message","You Have't Selected A Student to Delete!!",parent=self.root)
    def Classifier_after_Delete(self):
        if os.path.exists('Data/*.jpg'):
            data_dir = ("Data")
            path = [os.path.join(data_dir, file) for file in os.listdir(data_dir)]
            faces = []
            ids = []
            for image in path:
                img = Image.open(image).convert('L')
                imageNP = np.array(img, 'uint8')
                id = int(os.path.split(image)[1].split('.')[1])
                faces.append(imageNP)
                ids.append(id)
                # cv2.imshow("Traning Images", imageNP)
                cv2.waitKey(1) == 13
            ids = np.array(ids)
            clf = cv2.face.LBPHFaceRecognizer_create()
            clf.train(faces, ids)
            clf.replace("Classifier.xml")
            # messagebox.showinfo("Sure", "Training Images completed!!!", parent=self.root)


















class Today_attendence:
    def __init__(self, root):
        self.root = root
        self.root.title("TOday's Attendence")
        self.root.geometry("800x750+0+0")
        bg_Img = Label(self.root, background="#FF6F91")
        bg_Img.place(x=0, y=0, width=800, height=700)
        UpperLabel=Label(bg_Img,background="#FEF7FF")
        UpperLabel.place(x=50,y=100,width=650,height=500)
        showBtn = Button(bg_Img, text="Back",command=lambda :self.root.destroy(), font=("times new roman", 12, "bold"), bd=0,
                         fg="black", bg="white")
        showBtn.place(x=600, y=30, width=100, height=40)
        #table Building
        scrool_x = ttk.Scrollbar(UpperLabel, orient=HORIZONTAL)
        scrool_y = ttk.Scrollbar(UpperLabel, orient=VERTICAL)
        self.Student_Table = ttk.Treeview(UpperLabel, columns=("roll", "Na", "dept", "Sem",'time'),
                                          xscrollcommand=scrool_x.set, yscrollcommand=scrool_y.set)
        scrool_x.pack(side=BOTTOM, fill=X)
        scrool_y.pack(side=RIGHT, fill=Y)
        scrool_y.config(command=self.Student_Table.yview)
        scrool_x.config(command=self.Student_Table.xview)
        self.Student_Table.heading("roll", text="Exam Roll No")
        self.Student_Table.heading("Na", text="Name")
        self.Student_Table.heading("dept", text="Departmet")
        self.Student_Table.heading("Sem", text="Semester")
        self.Student_Table.heading("time",text="Time")
        self.Student_Table['show'] = "headings"
        self.Student_Table.column("roll", width=100, minwidth=100, )
        self.Student_Table.column("Na", width=100, minwidth=100)
        self.Student_Table.column("dept", width=100, minwidth=100)
        self.Student_Table.column("Sem", width=100, minwidth=100)
        self.Student_Table.column("time",width=100,minwidth=100)
        self.Student_Table.pack(fill=BOTH, expand=1)
        self.autoShow()


    ####################################         FUCNTION FOR AUTO SHOW TODAY'S ATTENDENCE###################################
    def autoShow(self):
        try:
            self.Student_Table.delete(*self.Student_Table.get_children())
            conn = pymysql.connect(host="localhost", user="root", password="0000", database="project")
            curr = conn.cursor()
            curr.execute(
                "select EROLL,NAME,DEPT,SEM,TIME from Attendence where date=curdate()")
            values = curr.fetchall()
            if len(values) == 0:
                messagebox.showerror("Error", "Attendence For Today not marked!!", parent=self.root)
            else:
                for i in values:
                    self.Student_Table.insert("", END, values=i)
            conn.commit()
            conn.close()
        except Exception as es:
            messagebox.showerror("Error", f"error due to:{str(es)}", parent=self.root)




















if __name__ == "__main__":
    root = Tk()
    app = Teachers_Dashboard(root)
    root.mainloop()
