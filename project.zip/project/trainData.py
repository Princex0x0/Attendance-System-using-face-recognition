
from datetime import date
from tkinter import messagebox

import pymysql

def Average():
    try:
        con = pymysql.connect(host='localhost', user='root', password='0000', database='project')
        cur = con.cursor()

        cur.execute('select count(*) from attendence where eroll=%s and month(date)=%s',(str(333),str(6)),)
        x1 = cur.fetchone()
        cur.execute('select count(distinct(date)) from attendence where month(date)=%s', date.today().month)
        y1 = cur.fetchone()
        print(x1[0])
        print(y1[0])
        con.commit()
        con.close()
    except Exception as es:
        messagebox.showerror("Error", f"Error due to {str(es)}")




if __name__ == '__main__':
    Average()


