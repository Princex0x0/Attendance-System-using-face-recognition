import tkinter
from time import strftime
from tkinter import *
from tkinter import messagebox
from tkinter import ttk

import cv2
import numpy as np
import pymysql
from PIL import Image, ImageTk
from cmake import *
from tkcalendar import DateEntry

from HomePage import Teachers_Dashboard
from StuLoginPage import Student_Login_Page


# from pymysql import *


def main():
    win = Tk()
    app = Login_Window(win)
    win.mainloop()

    # ~~~~~~~~~~~~~~~~~~.................A Login Window Class...................~~~~~~~~~~~~~~~~#


class Login_Window:
    def __init__(self, root):
        self.root = root
        self.root.title("Login")
        self.root.geometry("1550x800+0+0")

        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~..............Whole Login window Background Image.................~~~~~~~~~~~~~#
        self.bg = ImageTk.PhotoImage(file=r"bokeh-colorful-lights-blurred-lm.jpg")

        lbl_bg = Label(self.root, image=self.bg)
        lbl_bg.place(x=0, y=0, relwidth=1, relheight=1)
        # ~~~~~~~~~~.....................Frame-1 Adminstrator Frame..............~~~~~~~~~~~~~~~~~~~~~~~~~~~#
        Fframe1 = Frame(self.root, bg="white")
        Fframe1.place(x=750, y=390, width=1240, height=280)
        # ~~~~~~~~......................Frame-2 Face Detection Stuff..............~~~~~~~~~~~~~~~~~~~~~~#
        Fframe2 = Frame(self.root, bg="white")
        Fframe2.place(x=0, y=90, width=630, height=280)
        # ~~~~~~~~~~~~~~~~~~~~~.........Icon for administrator Login..............~~~~~~~~~~~~~~~#

        img1 = Image.open(r"C:\Users\PRINCE\Desktop\project\OIP.jfif")
        img1 = img1.resize((100, 100), Image.Resampling.LANCZOS)
        self.photoimage1 = ImageTk.PhotoImage(img1)
        lblimg1 = Label(image=self.photoimage1, bg="green", borderwidth=0)
        lblimg1.place(x=800, y=400, width=100, height=100)
        # Logo for student
        img2 = Image.open(r"C:\Users\PRINCE\Desktop\project\download.jfif")
        img2 = img2.resize((100, 100), Image.Resampling.LANCZOS)
        self.photoimage2 = ImageTk.PhotoImage(img2)
        lblimg2 = Label(image=self.photoimage2, bg="red", borderwidth=0)
        lblimg2.place(x=10, y=100, width=100, height=100)
        # ~~~~~~~~~~~~~~~~~~~~~Lables For Guidence....................~~~~~~~~~~~~~~~#
        get_str = Label(Fframe1, text="Note:For Adminstrator Only", font=("times new roman", 20, "bold"), fg="black",
                        bg="white")
        get_str.place(x=190, y=38)
        get_str1 = Label(Fframe2, text="Initiate Attendence Taking System", font=("times new roman", 20, "bold"),
                         fg="black", bg="white")
        get_str1.place(x=150, y=50)
        # ~~~~~~~~~~~UserName Label~~~~~~~~~~~~~~~~#
        username = lbl = Label(Fframe1, text="Username", font=("times new roman", 15, "bold"), fg="black", bg="white")
        username.place(x=60, y=120)
        self.txtuser = ttk.Entry(Fframe1, font=("constantia", 13))
        self.txtuser.place(x=200, y=120, width=300)
        # ~~~~~~~~~~~~~~~~~~Password Taking ~~~~~~~~~~~~~~~~~~~~#
        password = lbl = Label(Fframe1, text="Password", font=("times new roman", 15, "bold"), fg="black", bg="white")
        password.place(x=60, y=160)

        self.txtpass = ttk.Entry(Fframe1, show="*", font=("constantia", 13))
        self.txtpass.place(x=200, y=160, width=300)
        # ~~~~~~~~~~~~~~~Login Button~~~~~~~~~~~~~~~~~~~~#
        loginbtn = Button(Fframe1, command=self.login, text="Login", font=("times new roman", 15, "bold"), bd=0,
                          relief=RIDGE, fg="black", cursor="hand2", bg="orangered", activeforeground="black",
                          activebackground="white")
        loginbtn.place(x=290, y=200, width=120, height=40)
        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~Register Button~~~~~~~~~~#
        registerbtn = Button(Fframe1, text="New User Register", command=self.register_window_open,
                             font=("times new roman", 15, "bold"), borderwidth=0, fg="black", bg="white",
                             cursor="hand2", activebackground="white")
        registerbtn.place(x=30, y=240, width=200)
        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Forgot Password Button~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
        forgetbtn = Button(Fframe1, command=self.Forgot_Pass, text="Forget Password",
                           font=("times new roman", 15, "bold"), borderwidth=0,
                           fg="black", bg="white", cursor="hand2", activebackground="white")
        forgetbtn.place(x=450, y=240, width=150)
        # __________________________________________Frame 2_______________________________
        StuReg = Button(Fframe2, text="Register Student", command=self.register_Student,
                        font=("times new roman", 15, "bold"), borderwidth=0,
                        fg="black", bg="orangered", cursor="hand2", activebackground="white")
        StuReg.place(x=480, y=130, width=150)
        StuLogin = Button(Fframe2, text="Student Login",command=self.Stud_Log,
                          font=("times new roman", 15, "bold"), borderwidth=0,
                          fg="black", bg="orangered", cursor="hand2", activebackground="white")
        StuLogin.place(x=480, y=200, width=150)
        TakeAt = Button(Fframe2, text="Give Attendence", command=self.main_app,
                        font=("times new roman", 15, "bold"), borderwidth=0,
                        fg="black", bg="orangered", cursor="hand2", activebackground="white")
        TakeAt.place(x=170, y=170, width=250)
        # Full Program Exit Button
        ExitBtm = Button(lbl_bg, text="Exit", font=("times new roman", 15, "bold"), command=lambda: self.root.destroy(),
                         bd=0, fg="black", background="orangered", activebackground="black", cursor="hand2")
        ExitBtm.place(x=1200, y=10, width=100, height=50)
        ######################---------------DAte Show -----------------------------------##############

        self.time_Lbel=tkinter.Label(lbl_bg,compound=tkinter.LEFT,font=('times',52,'bold'),bg='black',fg='yellow')
        self.time_Lbel.place(x=10,y=0)
        self.mytime_after()
    def mytime_after(self):
        self.time_string=strftime('%H:%M:%S %p')
        self.time_Lbel.after(1000,self.mytime_after)
        self.time_Lbel.config(text=self.time_string)


        ####################################### Open register At toplever#####################################################

    def register_window_open(self):
        self.new_window = Toplevel(self.root)
        self.app = Register_Teacher(self.new_window)

    def register_Student(self):
        self.new1_window = Toplevel(self.root)
        self.app1 = Student_Register(self.new1_window)

    def after_Fact(self):
        self.new_window = Toplevel(self.root)
        self.app = Teachers_Dashboard(self.new_window)
    def Stud_Log(self):
        self.nw_win=Toplevel(self.root)
        self.application=Student_Login_Page(self.nw_win)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~Login Stuff~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
    def login(self):
        if self.txtuser.get() == "" or self.txtpass.get() == "":
            messagebox.showerror("OOPS!!", "Username and Password Must be required",parent=self.root)
        else:
            try:
                con = pymysql.connect(host='localhost', user='root', password='0000', database='project')
                cur = con.cursor()
                cur.execute('select * from teacher where TID=%s and PASS=%s', (self.txtuser.get(), self.txtpass.get()))
                row = cur.fetchone()
                if row == None:
                    messagebox.showerror("Error", "Invalid UserNmae or Password", parent=self.root)
                    self.txtuser.delete(0, END)
                    self.txtpass.delete(0, END)
                    self.txtuser.focus()
                else:
                    self.after_Fact()
                    self.txtuser.delete(0, END)
                    self.txtpass.delete(0, END)
                    self.txtuser.focus()
                    con.close()
            except Exception as es:
                messagebox.showerror('Error', f'Error Due to : {str(es)}', parent=self.root)

    def Forgot_Pass(self):
        try:
            if self.txtuser.get() == "":
                messagebox.showerror('Error', 'User Must Enter its Username',parent=self.root)
            else:
                con = pymysql.connect(host='localhost', user='root', password='0000', database='project')
                cur = con.cursor()
                cur.execute('select TID from teacher where TID=%s', self.txtuser.get())
                row = cur.fetchone()
                if row == None:
                    messagebox.showerror("Error", "Enterd UserName Not Contained in our Database", parent=self.root)
                else:
                    self.root2 = Toplevel()
                    self.root2.title("Forgot Password")
                    self.root2.geometry("440x800+0+0")
                    l = Label(self.root2, text="Forgot Password", font=("monospace", 15, "bold"))
                    l.place(x=10, y=30, relwidth=1)
                    SelQue = Label(self.root2, text="Select Question", font=("times new roman", 14, "bold"),
                                   bg="white")
                    SelQue.place(x=50, y=100)
                    self.Rcombo_que = ttk.Combobox(self.root2, font=("times new roman", 14, "bold"), state="readonly")
                    self.Rcombo_que["values"] = ("Select", "your Birth Place?", "Your Pet Name?", "Your Birth Year?")
                    self.Rcombo_que.place(x=50, y=130, width=225)
                    self.Rcombo_que.current(0)
                    SelAns = Label(self.root2, text="Answer", font=("times new roman", 17, "bold"), bg="white",
                                   fg="black")
                    SelAns.place(x=50, y=190)
                    self.RSelAns = ttk.Entry(self.root2, font=("monospace", 15, "italic"))
                    self.RSelAns.place(x=50, y=220)
                    self.Butt = Button(self.root2, command=self.forgot_thing, text="Check",
                                       font=("monospace", 14, "bold"), foreground="green",
                                       background="yellow")
                    self.Butt.place(x=130, y=300, width=100)
                    con.commit()
                    con.close()
        except EXCEPTION as es:
            messagebox.showerror("Error", f"Error due to {str(es)}", parent=self.root2)

    def forgot_thing(self):
        try:
            var1 = StringVar()

            con = pymysql.connect(host='localhost', user='root', password='0000', database='project')
            cur = con.cursor()
            cur.execute('select SEQQ from teacher where SEQQ=%s', self.Rcombo_que.get())
            row = cur.fetchone()
            cur.execute('select SEQA from teacher where TID=%s', self.txtuser.get())
            row1 = cur.fetchone()
            if self.Rcombo_que.get() == "Select" or self.RSelAns.get() == "":
                messagebox.showerror("Error", "All fields are Mandatory!!", parent=self.root2)
            elif row == None:
                messagebox.showerror("Error", "Are u Certain U selected This Security Question", parent=self.root2)
            elif self.RSelAns.get() != row1[0]:
                messagebox.showerror("Error", "Wrong Sequrity Answer", parent=self.root2)
            else:
                self.txtpass.insert(0, row1[0])
                messagebox.showinfo("Success", "Now You can Login!", parent=self.root2)
                con.commit()
                con.close()
                self.root2.destroy()
        except EXCEPTION as es:
            messagebox.showerror("Error", f"Error due to {str(es)}", parent=self.root2)

    # The attendence taking Function
    def main_app(self):
        if not os.path.isfile("Classifier.xml"):
            messagebox.showinfo("INFO", "Please train the data first!!", parent=self.root)
        else:
            face_cascade = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')
            recognizer = cv2.face.LBPHFaceRecognizer_create()
            recognizer.read(f"Classifier.xml")
            cap = cv2.VideoCapture(0,cv2.CAP_DSHOW)
            while True:
                ret, frame = cap.read()
                # default_img = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
                faces = face_cascade.detectMultiScale(gray, 1.3, 5)
                for (x, y, w, h) in faces:
                    roi_gray = gray[y:y + h, x:x + w]
                    id, predict = recognizer.predict(roi_gray)
                    confidence=((100*(1-predict/300)))
                    if confidence>80:
                        con = pymysql.connect(host="localhost", user="root", password="0000", database="project")
                        cur = con.cursor()
                        cur.execute("select * from attendence where EROLL=%s AND DATE=CURDATE();", (id,))
                        result = cur.fetchone()
                        if result is None:
                            con1 = pymysql.connect(host="localhost", user="root", password="0000", database="project")
                            cur1 = con1.cursor()
                            sql = "insert into attendence(eroll,name,phone,mail,gen,attend,date,dept,sem,time)select eroll,name,phone,email,gen,\"P\",curdate(),dept,sem,curtime() from student where eroll=%s"
                            val = (id)
                            cur1.execute(sql, val)
                            con1.commit()
                            con1.close()
                        else:
                            cur.execute("Select NAME from student where EROLL=%s", (id,))
                            i = cur.fetchone()
                            i = "+".join(i)
                            cur.close()
                            font = cv2.FONT_HERSHEY_PLAIN
                            frame = cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)
                            frame = cv2.putText(frame, i, (x, y - 4), font, 1, (0, 255, 0), 1, cv2.LINE_8)
                    else:
                        text = "UnknownFace"
                        font = cv2.FONT_HERSHEY_PLAIN
                        frame = cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 0, 255), 2)
                        frame = cv2.putText(frame, text, (x, y - 4), font, 1, (0, 0, 255), 1, cv2.LINE_AA)
                cv2.imshow("image", frame)
                if cv2.waitKey(1) == 13:
                    break
            cap.release()
            cv2.destroyAllWindows()


















































class Register_Teacher:
    def __init__(self, root):
        self.root = root
        self.root.title("Register")
        self.root.geometry("1400x750+0+0")
        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~Variables~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        self.var_SeqQ = StringVar()
        self.var_Gen = StringVar()
        self.var_Dept = StringVar()

        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~FULL BACKGROUND IMAGE ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
        self.bg = ImageTk.PhotoImage(file=r"feather-focus-blur-sunset-5k-yv.jpg")
        bg_lbl = Label(self.root, image=self.bg)
        bg_lbl.place(x=0, y=0, relwidth=1, relheight=1, height=2, width=50)
        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~LEFT IMAGE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~`#

        self.bg1 = ImageTk.PhotoImage(file=r"bokeh-colorful-lights-blurred-lm.jpg")
        bg_lbl1 = Label(self.root, image=self.bg1)
        bg_lbl1.place(x=100, y=70, width=370, height=550)
        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~Register Frame~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
        Rframe = Frame(self.root, bg="white")
        Rframe.place(x=470, y=70, width=770, height=550)
        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~REGESTRATION LABEL~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
        Register_lbl = Label(Rframe, text="Registration Form", font=("times new roman", 25, "bold"), fg="orangered",
                             bg="white")
        Register_lbl.place(x=50, y=20)
        TiD = Label(Rframe, text="Teacher's ID", font=("times new roman", 17, "bold",), bg="white", fg="black")
        TiD.place(x=50, y=70)
        self.RegTID = ttk.Entry(Rframe, font=("monospace", 15, "italic"))
        self.RegTID.place(x=50, y=100)
        # !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!First_Name!!!!!!!!!!!!!!!!!!!!!!!!#
        F_Name = Label(Rframe, text="First Name", font=("times new roman", 17, "bold",), bg="white", fg="black")
        F_Name.place(x=50, y=150)
        self.RegF_Name = ttk.Entry(Rframe, font=("monospace", 15, "italic"))
        self.RegF_Name.place(x=50, y=180)
        ###################################################LAST NAME####################################################
        L_Name = Label(Rframe, text="Last Name", font=("times new roman", 17, "bold",), bg="white")
        L_Name.place(x=350, y=150)
        self.RegL_Name = ttk.Entry(Rframe, font=("monospace", 15, "italic"))
        self.RegL_Name.place(x=350, y=180)
        ############################################### Email Id###########################################################
        E_Mail = Label(Rframe, text="E-Mail", font=("times new roman", 17, "bold",), bg="white")
        E_Mail.place(x=350, y=70)
        self.RegEmail = ttk.Entry(Rframe, font=("monospace", 15, "italic"))
        self.RegEmail.place(x=350, y=100)
        #######################################PASSWORD #########################################
        Pass = Label(Rframe, text="Password", font=("times new roman", 17, "bold",), bg="white", fg="black")
        Pass.place(x=50, y=230)
        self.RegPass = ttk.Entry(Rframe, font=("monospace", 15, "italic"))
        self.RegPass.place(x=50, y=260)
        #########################################Confirm Password####################################
        ConfPass = Label(Rframe, text="Confirm Password", font=("times new roman", 17, "bold",), bg="white", fg="black")
        ConfPass.place(x=350, y=230)
        self.RegConPass = ttk.Entry(Rframe, font=("monospace", 15, "italic"))
        self.RegConPass.place(x=350, y=260)
        ##########################################SELECT SEQURITY QUESTION ##############################################
        SelQue = Label(Rframe, text="Select Question", font=("times new roman", 17, "bold"), bg="white")
        SelQue.place(x=50, y=310)
        ########################################SECURITY ANSWER##################################
        SelAns = Label(Rframe, text="Answer", font=("times new roman", 17, "bold"), bg="white", fg="black")
        SelAns.place(x=350, y=310)
        self.RegSelAns = ttk.Entry(Rframe, font=("monospace", 15, "italic"))
        self.RegSelAns.place(x=350, y=340)
        Dept = Label(Rframe, text="Department", font=("times new roman", 17, "bold"), bg="white")
        Dept.place(x=50, y=390)
        self.RegComDept = ttk.Combobox(Rframe, textvariable=self.var_Dept, font=("times new roman", 15, "bold"),
                                       state="readonly")
        self.RegComDept.place(x=50, y=420, width=225)
        self.RegComDept["values"] = ("Select", "Bsc CA", "Bsc IT")
        self.RegComDept.current(0)
        self.Regcombo_que = ttk.Combobox(Rframe, textvariable=self.var_SeqQ, font=("times new roman", 15, "bold"),
                                         state="readonly")
        self.Regcombo_que["values"] = ("Select", "your Birth Place?", "Your Pet Name?", "Your Birth Year?")
        self.Regcombo_que.place(x=50, y=340, width=225)
        self.Regcombo_que.current(0)

        ######################################################GENTER #########################
        RegGen = Label(Rframe, text="Gender", font=("times new roman", 17, "bold"), bg="white", fg="black")
        RegGen.place(x=350, y=390)
        self.ComboGen = ttk.Combobox(Rframe, textvariable=self.var_Gen, font=("times new roman", 15, "bold"),
                                     state="readonly")
        self.ComboGen["values"] = ("Select", "Male", "Female", "Other")
        self.ComboGen.place(x=350, y=420, width=225)
        self.ComboGen.current(0)

        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~Button~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
        self.Regbtm = Button(Rframe, text="Register", command=self.register_button,
                             font=("times new roman", 17, "bold"), borderwidth=0, cursor="hand2", bg="orangered",
                             activebackground="orangered")
        self.Regbtm.place(x=380, y=480, width=200, height="50")
        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~Back Button!~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
        self.BackBtn = Button(Rframe, text="Already Registred?Log in", command=self.des,
                              font=("times new roman", 17, "bold"), borderwidth=0, cursor="hand2", bg="white",
                              activebackground="white")
        self.BackBtn.place(x=20, y=480, width=300, height="50")

    def des(self):
        self.root.destroy()

    def register_button(self):
        if self.RegTID.get() == "" or self.RegEmail.get() == "" or self.RegF_Name.get() == "" or self.RegL_Name.get() == "" or self.RegPass.get() == "" or self.RegConPass.get() == "" or self.var_SeqQ.get() == "Select" or self.var_Dept.get() == "Select" or self.RegSelAns.get() == "" or self.var_Gen.get() == "Select":
            messagebox.showerror("Error", "Fields Cannot Be Empty", parent=self.root)
        elif self.RegPass.get() != self.RegConPass.get():
            messagebox.showerror("Error", "Diffrent Password entered", parent=self.root)
        else:
            try:
                con = pymysql.connect(host="localhost", user="root", password="0000", database="project")
                cur = con.cursor()
                cur.execute("select * from teacher where E_MAIL=%s", self.RegEmail.get())
                row = cur.fetchone()
                cur1 = con.cursor()
                cur1.execute("select * from teacher where TID=%s", self.RegTID.get())
                row1 = cur1.fetchone()
                if row != None:
                    messagebox.showerror("Error", "Email Address is Already Registred!!", parent=self.root)
                    self.RegEmail.delete(0, END)
                    self.RegEmail.focus()
                elif row1 != None:
                    messagebox.showerror("Error", "Enter UserName is Already Registered!!", parent=self.root)
                    self.RegTID.delete(0, END)
                    self.RegTID.focus()
                else:
                    cur2 = con.cursor()
                    cur2.execute(
                        " insert into teacher (TID,F_NAME,L_NAME,E_MAIL,PASS,GEN,SEQQ,SEQA,DEPT)values(%s,%s,%s,%s,%s,%s,%s,%s,%s)",
                        (self.RegTID.get(), self.RegF_Name.get(), self.RegL_Name.get(), self.RegEmail.get(),
                         self.RegPass.get(), self.var_Gen.get(), self.var_SeqQ.get(), self.RegSelAns.get(),
                         self.var_Dept.get()))
                    con.commit()
                    con.close()
                    messagebox.showinfo("Registred", "redirecting to login Page!!", parent=self.root)
                    self.root.destroy()
            except Exception as es:
                messagebox.showerror("Error", f"Erorr due to{str(es)} :", parent=self.root)


# __________________________________________________________Student Class_______________________________________________


class Student_Register:
    def __init__(self, root):
        self.root = root
        self.root.title("Login")
        self.root.geometry("1550x800+0+0")
        # Main Frame
        Frame_login1 = Frame(self.root, bg="black")
        Frame_login1.place(x=0, y=0, height=700, width=1550)

        self.bg = ImageTk.PhotoImage(file="feather-focus-blur-sunset-5k-yv.jpg", size=0.5)
        # SEcond Main Frame
        img = Label(Frame_login1, image=self.bg).place(x=0, y=0, width=1550, height=700)
        frame_imput2 = Frame(self.root, bg='white')
        frame_imput2.place(x=300, y=130, height=600, width=800)
        #  Heading
        label1 = Label(frame_imput2, text="Student Registration Form", font=('monospace', 32, 'bold'), fg="black",
                       bg="white")
        label1.place(x=45, y=20)
        # Exam Roll NO
        label2 = Label(frame_imput2, text="Exam Roll Number", font=("goudy old style", 17, "bold"), fg="orangered",
                       bg="white")
        label2.place(x=50, y=90)
        # Exam Roll NO TAKING BOX~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
        self.Sturoll = Entry(frame_imput2, font=("monospace", 15, "bold"), bg="lightgray")
        self.Sturoll.place(x=50, y=130, width=250, height=30)
        # Name ###########################################
        label03 = Label(frame_imput2, text=" FullName", font=("goudy old style", 17, "bold"), fg="orangered",
                        bg="white")
        label03.place(x=50, y=165)
        # FOR FIRST NAME################################
        self.Stuname = Entry(frame_imput2, font=("monospace", 15, "bold"), bg="lightgray", fg="black")
        self.Stuname.place(x=50, y=200, width=250, height=30)
        # Phone ###########################################
        label04 = Label(frame_imput2, text="Phone", font=("goudy old style", 17, "bold"), fg="orangered",
                        bg="white")
        label04.place(x=350, y=165)
        #  TEXT box Phone ################################
        self.Stuph = Entry(frame_imput2, font=("monospace", 15, "bold"), bg="lightgray", fg="black")
        self.Stuph.place(x=350, y=200, width=250, height=30)
        ###################################LABEL THREE FOR NAME ###########################################
        label05 = Label(frame_imput2, text="E-Mail-ID", font=("goudy old style", 17, "bold"), fg="orangered",
                        bg="white")
        label05.place(x=355, y=90)
        # EMail ################################
        self.Stumail = Entry(frame_imput2, font=("monospace", 15, "bold"), bg="lightgray", fg="black")
        self.Stumail.place(x=350, y=130, width=250, height=30)
        # PASSWORD #################################
        Stulabel05 = Label(frame_imput2, text="Password", font=("monospace", 17, "bold"), fg="orangered", bg="white")
        Stulabel05.place(x=50, y=375)
        # ENTRY BOX FOr password ################################
        self.Stupass = Entry(frame_imput2, font=("monospace", 15, "bold"), bg="lightgray", fg="black")
        self.Stupass.place(x=50, y=415, width=250, height=30)
        # Re #nter passwod#
        Reglabel05 = Label(frame_imput2, text="ReEnter Password", font=("goudy old style", 17, "bold"), fg="orangered",
                           bg="white")
        Reglabel05.place(x=350, y=375)
        # REenter Password
        self.StuConPass = Entry(frame_imput2, font=("monospace", 15, "bold"), bg="lightgray", fg="black")
        self.StuConPass.place(x=350, y=415, width=250, height=30)

        # Button for inserting data to Teacher database~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
        self.REGButton = Button(frame_imput2, text="Register", cursor="hand2", command=self.Stu_register,
                                font=("times new roman", 15, "bold"), activebackground="orangered", fg="white",
                                bg="orangered", bd=0, width=15, height=1)
        self.REGButton.place(x=600, y=500, width=200)
        # Combobox for Dept
        Reglabel05 = Label(frame_imput2, text="Department", font=("goudy old style", 17, "bold"), fg="orangered",
                           bg="white")
        Reglabel05.place(x=50, y=235)

        self.StuComDept = ttk.Combobox(frame_imput2, font=("times new roman", 15, "bold"), state="readonly")
        self.StuComDept.place(x=50, y=270, width=225)
        self.StuComDept["values"] = ("Select", "Bsc CA", "Bsc IT")
        self.StuComDept.current(0)
        # Semester U are IN
        Reglabel05 = Label(frame_imput2, text="Semester", font=("goudy old style", 17, "bold"), fg="orangered",
                           bg="white")
        Reglabel05.place(x=350, y=235)
        # Semester Combobox
        self.StuSem = ttk.Combobox(frame_imput2, font=("times new roman", 15, "bold"), state="readonly")
        self.StuSem.place(x=350, y=270, width=225)
        self.StuSem["values"] = ("Select", "SEM I", "SEM II", "SEM III", "SEM IV", "SEM V", "SEM VI")
        self.StuSem.current(0)
        # BirthDate
        Reglabel05 = Label(frame_imput2, text="Birth-Date", font=("goudy old style", 17, "bold"), fg="orangered",
                           bg="white")
        Reglabel05.place(x=50, y=305)
        # BirthDate Entry
        self.Stucal = DateEntry(frame_imput2, width=12, year=2022, month=1, font=("times new roman", 10, "bold"), day=1,
                                background='darkblue', foreground='white', borderwidth=2)
        self.Stucal.place(x=50, y=344, width=223)

        # Gender
        Reglabel05 = Label(frame_imput2, text="Gender", font=("goudy old style", 17, "bold"), fg="orangered",
                           bg="white")
        Reglabel05.place(x=350, y=300)
        self.StuGen = ttk.Combobox(frame_imput2, font=("times new roman", 15, "bold"), state="readonly")
        self.StuGen.place(x=350, y=340, width=225)
        self.StuGen["values"] = ("Select", "M", "F")
        self.StuGen.current(0)
        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~Button for Back~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
        self.StuBackButton = Button(frame_imput2, text="Back", command=self.StuDes, cursor="hand2",
                                    font=("times new roman", 15, "bold"), activebackground="orangered", fg="white",
                                    bg="orangered", bd=0, width=15, height=1)



        regLabel=Label(frame_imput2,text="Security Question",font=("goudy old style",17,"bold"),fg="orangered",bg="white")
        regLabel.place(x=50,y=450)



        self.StuBackButton.place(x=600, y=50, width=200)
        self.SeqQ = ttk.Combobox(frame_imput2, font=("times new roman", 15, "bold"),
                                         state="readonly")
        self.SeqQ["values"] = ("Select", "your Birth Place?", "Your Pet Name?", "Your Birth Year?")
        self.SeqQ.place(x=50, y=500, width=225)
        self.SeqQ.current(0)
        labelforseqA=Label(frame_imput2,text="Security Answer",font=("goudy old style",17,"bold"),fg="orangered",bg="white")
        labelforseqA.place(x=350,y=450)
        self.SeqA = Entry(frame_imput2, font=("monospace", 15, "bold"), bg="lightgray", fg="black")
        self.SeqA.place(x=350, y=500, width=250, height=30)

    def Stu_register(self):
        if self.SeqA.get()=="" or self.SeqQ.get()=="Select" or self.Sturoll.get() == "" or self.Stumail.get() == "" or self.Stuname.get() == "" or self.Stuph.get() == "" or self.StuComDept.get() == "Select" or self.StuGen.get() == "Select" or self.Stupass.get() == "" or self.StuConPass.get() == "" or self.Stucal.get() == "1/1/22":
            messagebox.showerror("Error", "All Fields Must be Filled!!", parent=self.root)
        elif self.Stupass.get() != self.StuConPass.get():
            messagebox.showerror("Error", "Entered Password are Diffrent", parent=self.root)
        else:
            try:
                con = pymysql.connect(host="localhost", user="root", password="0000", database="project")
                cur = con.cursor()
                cur.execute("select * from student where EMAIL=%s", self.Stumail.get())
                row = cur.fetchone()
                cur1 = con.cursor()
                cur1.execute("select EROLL from student where EROLL=%s", self.Sturoll.get())
                row1 = cur1.fetchone()
                if row != None:
                    messagebox.showerror("Error", "Email Address is Already Registred!!", parent=self.root)
                    self.Stumail.delete(0, END)
                    self.Stumail.focus()
                elif row1 != None:
                    messagebox.showerror("Error", "Enter RollNumber is Already Registered!!", parent=self.root)
                    self.Sturoll.delete(0, END)
                    self.Sturoll.focus()
                else:
                    cur2 = con.cursor()
                    cur2.execute(
                        " insert into student (EROLL,EMAIL,NAME,PHONE,DEPT,SEM,BIRTH,GEN,PASS,SEQQ,SEQA)values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)",
                        (
                            self.Sturoll.get(), self.Stumail.get(), self.Stuname.get(), self.Stuph.get(),
                            self.StuComDept.get(), self.StuSem.get(), self.Stucal.get_date(), self.StuGen.get(),
                            self.Stupass.get(),self.SeqQ.get(),self.SeqA.get()))
                    con.commit()
                    con.close()
                    messagebox.showinfo("Opening Camera for Taking Sample Images!!", parent=self.root)
                    # self.root.destroy()
                    face_classifier = cv2.CascadeClassifier("haarcascade_frontalface_default.xml")
                    # FACE CAPTURE
                    try:
                        def face_cropped(img):
                            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
                            faces = face_classifier.detectMultiScale(gray, 1.3, 5)
                            for (x, y, w, h) in faces:
                                face_cropped = img[y:y + h, x:x + h]
                                return face_cropped

                        cap = cv2.VideoCapture(0)
                        img_id = 0
                        while True:
                            ret, my_frame = cap.read()
                            if face_cropped(my_frame) is not None:
                                img_id += 1
                            face = cv2.resize(face_cropped(my_frame), (450, 450))
                            face = cv2.cvtColor(face, cv2.COLOR_BGR2GRAY)
                            file_name_path = "Data/user." + self.Sturoll.get() + "." + str(img_id) + ".jpg"
                            cv2.imwrite(file_name_path, face)
                            cv2.putText(face, str(img_id), (50, 50), cv2.FONT_HERSHEY_COMPLEX_SMALL, 2, (0, 0, 255), 2)
                            cv2.imshow("Crooped Face", face)
                            if cv2.waitKey(1) == 12 or int(img_id) == 100:
                                break;
                        cap.release()
                        cv2.destroyAllWindows()
                        # Training Images
                        data_dir = ("Data")
                        path = [os.path.join(data_dir, file) for file in os.listdir(data_dir)]
                        faces = []
                        ids = []
                        for image in path:
                            img = Image.open(image).convert('L')
                            imageNP = np.array(img, 'uint8')
                            id = int(os.path.split(image)[1].split('.')[1])
                            faces.append(imageNP)
                            ids.append(id)
                            # cv2.imshow("Traning Images", imageNP)
                            cv2.waitKey(1) == 13
                        ids = np.array(ids)
                        clf = cv2.face.LBPHFaceRecognizer_create()
                        clf.train(faces, ids)
                        clf.write("Classifier.xml")
                        # messagebox.showinfo("Sure", "Training Images completed!!!", parent=self.root)
                        self.root.destroy()
                    except Exception as es:
                        messagebox.showinfo("Faulty", "Traning Imgae failed Try Again!!!")
                        con = pymysql.connect(host="localhost", user="root", password="0000", database="project")
                        cur = con.cursor()
                        cur.execute("delete from student where EROLL=%s", self.Sturoll.get())
                        con.commit()
                        con.close()

            except Exception as es:
                messagebox.showerror("Error", f"Error Due to {str(es)}", parent=self.root)




    # Face Photo Taking Camera initialization

    def StuDes(self):
        self.root.destroy()


if __name__ == "__main__":
    main()
