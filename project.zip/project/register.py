from tkinter import *
from tkinter import messagebox
from tkinter import ttk, StringVar

import pymysql
from PIL import ImageTk


class Register:

    def __init__(self, root):
        self.root = root
        self.root.title("Register")
        self.root.geometry("1400x750+0+0")
        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~Variables~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        # self.var_TID=StringVar()
        # self.var_Email = StringVar()
        # self.var_FName = StringVar()
        # self.var_LName = StringVar()
        self.var_SeqQ = StringVar()
        # self.var_SeqA= StringVar()
        # self.var_Pass = StringVar()
        # self.var_CPass = StringVar()
        self.var_Gen = StringVar()
        self.var_Dept = StringVar()

        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~FULL BACKGROUND IMAGE ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
        self.bg = ImageTk.PhotoImage(file=r"feather-focus-blur-sunset-5k-yv.jpg")
        bg_lbl = Label(self.root, image=self.bg)
        bg_lbl.place(x=0, y=0, relwidth=1, relheight=1, height=2, width=50)
        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~LEFT IMAGE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~`#

        self.bg1 = ImageTk.PhotoImage(file=r"bokeh-colorful-lights-blurred-lm.jpg")
        bg_lbl1 = Label(self.root, image=self.bg1)
        bg_lbl1.place(x=100, y=70, width=370, height=550)
        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~Register Frame~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
        frame = Frame(self.root, bg="white").place(x=470, y=70, width=770, height=550)
        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~REGESTRATION LABEL~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
        Register_lbl = Label(frame, text="Registration Form", font=("times new roman", 25, "bold"), fg="orangered",
                             bg="white").place(x=500, y=100)
        TiD = Label(frame, text="Teacher's ID", font=("times new roman", 17, "bold",), bg="white", fg="black").place(
            x=500, y=170)
        self.RegTID = ttk.Entry(frame, font=("monospace", 15, "italic"))
        self.RegTID.place(x=500, y=200)
        # !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!First_Name!!!!!!!!!!!!!!!!!!!!!!!!#
        F_Name = Label(frame, text="First Name", font=("times new roman", 17, "bold",), bg="white", fg="black").place(
            x=500, y=240)
        self.RegF_Name = ttk.Entry(frame, font=("monospace", 15, "italic"))
        self.RegF_Name.place(x=500, y=270)
        ###################################################LAST NAME####################################################
        L_Name = Label(frame, text="Last Name", font=("times new roman", 17, "bold",), bg="white").place(x=800, y=240)
        self.RegL_Name = ttk.Entry(frame, font=("monospace", 15, "italic"))
        self.RegL_Name.place(x=800, y=270)
        ############################################### Email Id###########################################################
        E_Mail = Label(frame, text="E-Mail", font=("times new roman", 17, "bold",), bg="white").place(x=800, y=170)
        self.RegEmail = ttk.Entry(frame, font=("monospace", 15, "italic"))
        self.RegEmail.place(x=800, y=200)
        #######################################PASSWORD #########################################
        Pass = Label(frame, text="Password", font=("times new roman", 17, "bold",), bg="white", fg="black").place(x=500,
                                                                                                                  y=320)
        self.RegPass = ttk.Entry(frame, font=("monospace", 15, "italic"))
        self.RegPass.place(x=500, y=350)
        #########################################Confirm Password####################################
        ConfPass = Label(frame, text="Confirm Password", font=("times new roman", 17, "bold",), bg="white",
                         fg="black").place(x=800, y=320)
        self.RegConPass = ttk.Entry(frame, font=("monospace", 15, "italic"))
        self.RegConPass.place(x=800, y=350)
        ##########################################SELECT SEQURITY QUESTION ##############################################
        SelQue = Label(frame, text="Select Question", font=("times new roman", 17, "bold"), bg="white").place(x=500,
                                                                                                              y=390)
        ########################################SECURITY ANSWER##################################
        SelAns = Label(frame, text="Answer", font=("times new roman", 17, "bold"), bg="white", fg="black").place(x=800,
                                                                                                                 y=390)
        self.RegSelAns = ttk.Entry(frame, font=("monospace", 15, "italic"))
        self.RegSelAns.place(x=800, y=420)
        Dept = Label(frame, text="Department", font=("times new roman", 17, "bold"), bg="white").place(x=500, y=460)
        self.RegComDept = ttk.Combobox(frame, textvariable=self.var_Dept, font=("times new roman", 15, "bold"),
                                       state="readonly")
        self.RegComDept.place(x=500, y=490, width=225)
        self.RegComDept["values"] = ("Select", "Bsc.Ca", "Bsc It")
        self.RegComDept.current(0)
        self.Regcombo_que = ttk.Combobox(frame, textvariable=self.var_SeqQ, font=("times new roman", 15, "bold"),
                                         state="readonly")
        self.Regcombo_que["values"] = ("Select", "your Birth Place?", "Your Pet Name?", "Your Birth Year?")
        self.Regcombo_que.place(x=500, y=420, width=225)
        self.Regcombo_que.current(0)

        ######################################################GENTER #########################
        Label(frame, text="Gender", font=("times new roman", 17, "bold"), bg="white", fg="black").place(x=800, y=460)
        self.ComboGen = ttk.Combobox(frame, textvariable=self.var_Gen, font=("times new roman", 15, "bold"),
                                     state="readonly")
        self.ComboGen["values"] = ("Select", "Male", "Female", "Other")
        self.ComboGen.place(x=800, y=490, width=225)
        self.ComboGen.current(0)


        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~Button~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
        self.Regbtm = Button(frame, text="Register", command=self.register_button, font=("times new roman", 17, "bold"),
                             borderwidth=0, cursor="hand2", bg="orangered", activebackground="orangered")
        self.Regbtm.place(x=1000, y=540, width=200, height="50")
        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~Back Button!~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
        self.BackBtn = Button(frame, text="Already Registred?Log in", font=("times new roman", 17, "bold"),
                              borderwidth=0, cursor="hand2", bg="white", activebackground="white")
        self.BackBtn.place(x=480, y=540, width=300, height="50")

    def register_button(self):
        if self.RegTID.get() == "" or self.RegEmail.get() == "" or self.RegF_Name.get() == "" or self.RegL_Name.get() == "" or self.RegPass.get() == "" or self.RegConPass.get() == "" or self.var_SeqQ.get() == "Select" or self.var_Dept.get() == "Select" or self.RegSelAns.get() == "" or self.var_Gen.get() == "Select":
            messagebox.showerror("Error", "Fields Cannot Be Empty", parent=self.root)
        elif self.RegPass.get() != self.RegConPass.get():
            messagebox.showerror("Error", "Diffrent Password entered", parent=self.root)
        else:
            try:
                con = pymysql.connect(host="localhost", user="root", password="0000", database="project")
                cur = con.cursor()
                cur.execute("select * from teacher where E_MAIL=%s", self.RegEmail.get())
                row = cur.fetchone()
                cur1 = con.cursor()
                cur1.execute("select * from teacher where TID=%s", self.RegTID.get())
                row1 = cur1.fetchone()
                if row != None:
                    messagebox.showerror("Error", "Email Address is Already Registred!!", parent=self.root)
                    self.RegEmail.delete(0, END)
                    self.RegEmail.focus()
                elif row1 != None:
                    messagebox.showerror("Error", "Enter UserName is Already Registered!!", parent=self.root)
                    self.RegTID.delete(0, END)
                    self.RegTID.focus()
                else:
                    cur2 = con.cursor()
                    cur2 = con.cursor()
                    cur2.execute(
                        " insert into teacher (TID,F_NAME,L_NAME,E_MAIL,PASS,GEN,SEQQ,SEQA,DEPT)values(%s,%s,%s,%s,%s,%s,%s,%s,%s)",
                        (self.RegTID.get(), self.RegF_Name.get(), self.RegL_Name.get(), self.RegEmail.get(),
                         self.RegPass.get(), self.var_Gen.get(), self.var_SeqQ.get(), self.RegSelAns.get(),
                         self.var_Dept.get()))
                    con.commit()
                    con.close()
                    messagebox.showinfo("Registred", "redirecting to home!!", parent=self.root)
            except Exception as es:
                messagebox.showerror("Error", f"Erorr due to{str(es)} :", parent=self.root)


if __name__ == "__main__":
    root = Tk()
    app = Register(root)
    root.mainloop()
